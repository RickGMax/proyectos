# CellSwarm 3D

Versión tridimensional de `cellswar2D.py`. Conserva el flocking, la infección,
la huida, la caza y el ataque inmunitario, pero calcula toda la dinámica en un
volumen `(x, y, z)` con `scipy.spatial.KDTree`.

## Colisión y adhesión

- Un KD-tree físico detecta las parejas próximas sin comparar cada célula con
  todas las demás.
- Los contactos corrigen penetración, eliminan casi todo el rebote y aplican
  fricción tangencial para evitar el solapamiento visible.
- Cuando una célula cancerígena toca un eritrocito se crea una adhesión elástica
  amortiguada. Permanecen unidas por la membrana, pero el enlace puede romperse
  si las fuerzas las separan lo suficiente.
- La persecución cancerígena se detiene a distancia de contacto y ya no intenta
  alcanzar el centro del eritrocito.

## Geometrías

- **Eritrocito:** disco bicóncavo cerrado. La concavidad es geometría real y no
  una esfera disfrazada mediante una textura.
- **T-killer:** esfera ligeramente granulada.
- **Cáncer:** malla orgánica irregular con lóbulos y espículas.

Las tres texturas de color fueron preparadas a partir de la referencia adjunta.
El shader extrae de ellas el microrrelieve y combina iluminación difusa,
especular, rugosidad y luz de contorno.

## Instalación y ejecución

En PowerShell, dentro de esta carpeta:

```powershell
py -m pip install -r requirements.txt
py cellswar3D.py
```

Usando `uv`:

```powershell
uv pip install -r requirements.txt
uv run python cellswar3D.py
```

## Controles

| Control | Acción |
|---|---|
| Arrastrar con botón izquierdo | Orbitar si no hay modo de inserción |
| Arrastrar con botón derecho | Orbitar siempre |
| Rueda | Zoom |
| `H`, `C`, `W` | Elegir eritrocito, cáncer o T-killer |
| Clic izquierdo | Insertar la célula seleccionada en el plano de enfoque |
| `G` | Mostrar u ocultar la grilla 3D |
| `P` | Pausar |
| `R` | Reiniciar |
| `Esc` | Cancelar modo; cerrar si no hay modo activo |

## Nota de rendimiento

La simulación usa una sola reconstrucción de cada KD-tree por cuadro. El render
mantiene las mallas y texturas residentes en GPU; solo actualiza la matriz de
modelo de cada célula.
