"""Simulación tridimensional de eritrocitos, células T y células cancerígenas.

Conversión de cellswar2D.py a un volumen 3D real.  La dinámica sigue usando
KDTree, ahora con posiciones (x, y, z), y el render se realiza con ModernGL.

Controles
---------
Arrastrar botón derecho       orbitar cámara
Rueda                         acercar/alejar
H / C / W                     modo de inserción (eritrocito/cáncer/T-killer)
Clic izquierdo                insertar en el plano de enfoque
G                             mostrar/ocultar grilla 3D
P                             pausar
R                             reiniciar
ESC                           cancelar modo; cerrar si no hay modo
"""

from __future__ import annotations

import math
import random
from pathlib import Path

import moderngl
import numpy as np
import pyglet
from PIL import Image
from pyglet.window import key, mouse
from scipy.spatial import KDTree


# Configuración

WIDTH, HEIGHT = 1200, 850
WORLD = np.array((32.0, 22.0, 18.0), dtype=np.float32)

NUM_ERYTHROCYTES = 40
NUM_CANCER = 3
NUM_TKILLER = 5

MAX_SPEED = 2.15
MAX_FORCE = 1.35
NEIGHBOR_RADIUS = 3.2
SEPARATION_RADIUS = 1.25
FEAR_RADIUS = 4.0
CANCER_HUNT_RADIUS = 6.2
CLUSTER_BOOST_MIN = 4
OVERCROWD_RADIUS = 1.55
OVERCROWD_N = 5

INFECTION_RADIUS = 1.45
INFECTION_RATE = 0.38             # probabilidad continua por segundo
TKILLER_KILL_RADIUS = 1.05
TKILLER_SPEED = 4.2
TKILLER_DETECT_RADIUS = 9.5

# Contacto celular 3D. Los colliders son esferas algo menores que la silueta
# visual: las membranas parecen blandas, pero nunca atraviesan el centro vecino.
COLLISION_SKIN = 0.025
COLLISION_CORRECTION = 1.0
COLLISION_RESTITUTION = 0.015       # prácticamente sin rebote
COLLISION_FRICTION = 0.16
COLLISION_QUERY_RADIUS = 1.90

# Adhesión selectiva cáncer-eritrocito (resorte amortiguado y rompible).
ADHESION_CAPTURE_RANGE = 0.24
ADHESION_BREAK_RANGE = 0.78
ADHESION_STIFFNESS = 7.5
ADHESION_DAMPING = 2.6
ADHESION_TANGENTIAL_DRAG = 0.48
ADHESION_MAX_FORCE = 5.5

ASSET_DIR = Path(__file__).resolve().parent / "assets"

# Álgebra lineal

def normalize(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return v / n if n > 1e-8 else np.zeros_like(v)


def limit(v: np.ndarray, maximum: float) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return v * (maximum / n) if n > maximum else v


def perspective(fov_y: float, aspect: float, near: float, far: float) -> np.ndarray:
    f = 1.0 / math.tan(fov_y * 0.5)
    return np.array([
        [f / aspect, 0, 0, 0],
        [0, f, 0, 0],
        [0, 0, (far + near) / (near - far), 2 * far * near / (near - far)],
        [0, 0, -1, 0],
    ], dtype=np.float32)


def look_at(eye: np.ndarray, target: np.ndarray, up: np.ndarray) -> np.ndarray:
    f = normalize(target - eye)
    s = normalize(np.cross(f, up))
    u = np.cross(s, f)
    return np.array([
        [s[0], s[1], s[2], -np.dot(s, eye)],
        [u[0], u[1], u[2], -np.dot(u, eye)],
        [-f[0], -f[1], -f[2], np.dot(f, eye)],
        [0, 0, 0, 1],
    ], dtype=np.float32)


def translation(v: np.ndarray) -> np.ndarray:
    m = np.eye(4, dtype=np.float32)
    m[:3, 3] = v
    return m


def axis_rotation(axis: np.ndarray, angle: float) -> np.ndarray:
    x, y, z = normalize(axis)
    c, s, q = math.cos(angle), math.sin(angle), 1.0 - math.cos(angle)
    return np.array([
        [c + x*x*q, x*y*q - z*s, x*z*q + y*s, 0],
        [y*x*q + z*s, c + y*y*q, y*z*q - x*s, 0],
        [z*x*q - y*s, z*y*q + x*s, c + z*z*q, 0],
        [0, 0, 0, 1],
    ], dtype=np.float32)


def upload_matrix(uniform, matrix: np.ndarray) -> None:
    uniform.write(np.ascontiguousarray(matrix.T, dtype="f4").tobytes())



# Geometría corregida

def indexed_mesh(positions, uvs, triangles):
    """Calcula normales suaves y devuelve vértices intercalados + índices."""
    p = np.asarray(positions, dtype=np.float32)
    uv = np.asarray(uvs, dtype=np.float32)
    idx = np.asarray(triangles, dtype=np.uint32).reshape(-1, 3)
    normals = np.zeros_like(p)
    for a, b, c in idx:
        n = np.cross(p[b] - p[a], p[c] - p[a])
        normals[a] += n
        normals[b] += n
        normals[c] += n
    lengths = np.linalg.norm(normals, axis=1, keepdims=True)
    # En los polos de una esfera UV todas las caras pueden degenerar sobre el
    # mismo punto. Usar allí la dirección radial evita normales nulas/artefactos.
    degenerate = lengths[:, 0] < 1e-8
    normals /= np.maximum(lengths, 1e-8)
    if np.any(degenerate):
        radial = p[degenerate]
        radial /= np.maximum(np.linalg.norm(radial, axis=1, keepdims=True), 1e-8)
        normals[degenerate] = radial
    return np.hstack((p, normals, uv)).astype("f4"), idx.ravel()


def make_erythrocyte(radial=26, angular=64):
    """Disco bicóncavo cerrado; la concavidad pertenece a la malla, no al mapa."""
    pos, uv, tri = [], [], []
    for side in (-1.0, 1.0):
        base = len(pos)
        for ir in range(radial + 1):
            r = ir / radial
            # Delgado al centro, grueso en el anillo y cerrado en el borde.
            h = 0.20 * math.sqrt(max(0.0, 1.0 - r*r)) * (1.0 + 2.45*r*r)
            for ia in range(angular):
                phi = 2.0 * math.pi * ia / angular
                x, y = 0.82*r*math.cos(phi), 0.82*r*math.sin(phi)
                pos.append((x, y, side*h))
                uv.append((0.5 + 0.5*r*math.cos(phi), 0.5 + 0.5*r*math.sin(phi)))
        for ir in range(radial):
            for ia in range(angular):
                nb = (ia + 1) % angular
                a = base + ir*angular + ia
                b = base + ir*angular + nb
                c = base + (ir+1)*angular + ia
                d = base + (ir+1)*angular + nb
                if side > 0:
                    tri.extend(((a, c, b), (b, c, d)))
                else:
                    tri.extend(((a, b, c), (b, d, c)))
    return indexed_mesh(pos, uv, tri)


def make_uv_sphere(kind: str, stacks=36, slices=64):
    """Esfera granular T o célula cancerígena orgánica y espiculada."""
    pos, uv, tri = [], [], []
    for iy in range(stacks + 1):
        theta = math.pi * iy / stacks
        for ix in range(slices + 1):
            phi = 2.0 * math.pi * ix / slices
            if kind == "tkiller":
                radius = 0.69 * (1.0 + 0.018*math.sin(13*phi)*math.sin(11*theta))
            else:
                folds = 0.075*math.sin(5*phi + 1.7*math.sin(3*theta))*math.sin(7*theta)
                lumps = 0.055*math.sin(3*phi - 5*theta) + 0.035*math.sin(11*phi + 4*theta)
                spikes = 0.15 * max(0.0, math.sin(9*phi + 7*theta))**7
                radius = 0.82 * (1.0 + folds + lumps + spikes)
            st = math.sin(theta)
            pos.append((radius*st*math.cos(phi), radius*math.cos(theta), radius*st*math.sin(phi)))
            uv.append((ix / slices, 1.0 - iy / stacks))
    row = slices + 1
    for iy in range(stacks):
        for ix in range(slices):
            a, b = iy*row + ix, iy*row + ix + 1
            c, d = (iy+1)*row + ix, (iy+1)*row + ix + 1
            tri.extend(((a, b, c), (b, d, c)))
    return indexed_mesh(pos, uv, tri)



# Simulación 3D

class Agent:
    def __init__(self, position, velocity, kind: str):
        self.position = np.asarray(position, dtype=np.float32)
        self.velocity = np.asarray(velocity, dtype=np.float32)
        self.acceleration = np.zeros(3, dtype=np.float32)
        self.kind = kind
        self.alive = True
        self.spin_axis = normalize(np.random.uniform(-1, 1, 3).astype(np.float32))
        self.angle = random.uniform(0, math.tau)
        self.spin_speed = random.uniform(-0.45, 0.45)

    @property
    def cancer(self):
        return self.kind == "cancer"

    @property
    def radius(self):
        return 0.82 if self.cancer else 0.82

    @property
    def collision_radius(self):
        if self.kind == "cancer":
            return 0.76
        if self.kind == "tkiller":
            return 0.63
        return 0.70

    @property
    def inverse_mass(self):
        if self.kind == "cancer":
            return 1.0 / 1.40
        if self.kind == "tkiller":
            return 1.0 / 0.90
        return 1.0

    @property
    def max_speed(self):
        return MAX_SPEED * (1.10 if self.cancer else 1.0)

    def apply_force(self, force):
        self.acceleration += force

    def alignment(self, neighbors):
        if not neighbors:
            return np.zeros(3, dtype=np.float32)
        desired = normalize(np.mean([n.velocity for n in neighbors], axis=0)) * self.max_speed
        return limit(desired - self.velocity, MAX_FORCE)

    def cohesion(self, neighbors):
        if not neighbors:
            return np.zeros(3, dtype=np.float32)
        desired = normalize(np.mean([n.position for n in neighbors], axis=0) - self.position)
        return limit(desired*self.max_speed - self.velocity, MAX_FORCE)

    def separation(self, neighbors, radius):
        steering = np.zeros(3, dtype=np.float32)
        count = 0
        for other in neighbors:
            offset = self.position - other.position
            d = float(np.linalg.norm(offset))
            if 1e-6 < d < radius:
                steering += offset / (d*d)
                count += 1
        if not count:
            return steering
        desired = normalize(steering / count) * self.max_speed
        return limit(desired - self.velocity, MAX_FORCE)

    def flock(self, sim: "Simulation"):
        if self.cancer:
            near = sim.cancer_neighbors(self.position, NEIGHBOR_RADIUS, exclude=self)
            self.apply_force(0.12*self.alignment(near) + 0.9*self.separation(near, SEPARATION_RADIUS))
            target, distance = sim.nearest_erythrocyte(self.position)
            if target is not None and distance < CANCER_HUNT_RADIUS:
                toward = target.position - self.position
                contact_distance = self.collision_radius + target.collision_radius
                surface_gap = distance - contact_distance
                # Frenar al llegar a la membrana evita que el steering empuje
                # continuamente al cáncer hacia el centro del eritrocito.
                if surface_gap > 0.06:
                    approach_speed = self.max_speed * min(1.0, surface_gap / 1.4)
                    desired = normalize(toward) * approach_speed
                else:
                    desired = np.zeros(3, dtype=np.float32)
                self.apply_force(limit(desired - self.velocity, 1.5*MAX_FORCE))
            self.apply_force(np.random.uniform(-1, 1, 3).astype(np.float32)*0.38)
            return

        neighbors = sim.all_neighbors(self.position, NEIGHBOR_RADIUS, exclude=self)
        self.apply_force(self.alignment(neighbors))
        self.apply_force(0.8*self.cohesion(neighbors))
        self.apply_force(1.5*self.separation(neighbors, SEPARATION_RADIUS))

        threats = sim.cancer_neighbors(self.position, FEAR_RADIUS)
        if threats:
            flee = sum((self.position-t.position) /
                       max(float(np.dot(self.position-t.position, self.position-t.position)), 1e-5)
                       for t in threats)
            self.apply_force(limit(flee, 1.4*MAX_FORCE))

        close = sim.erythrocyte_neighbors(self.position, 0.6*NEIGHBOR_RADIUS)
        if len(close) >= CLUSTER_BOOST_MIN:
            self.apply_force(normalize(self.velocity)*0.55)
        crowd = sim.erythrocyte_neighbors(self.position, OVERCROWD_RADIUS)
        if len(crowd) > OVERCROWD_N:
            self.apply_force(2.0*self.separation(crowd, OVERCROWD_RADIUS))

    def integrate(self, dt):
        self.velocity = limit(self.velocity + self.acceleration*dt, self.max_speed)
        self.position += self.velocity*dt
        self.acceleration[:] = 0
        self.angle += self.spin_speed*dt
        # Mundo toroidal en los tres ejes.
        half = WORLD*0.5
        self.position[:] = (self.position + half) % WORLD - half

    def model_matrix(self):
        return translation(self.position) @ axis_rotation(self.spin_axis, self.angle)


class TKiller(Agent):
    def __init__(self, position, velocity):
        super().__init__(position, velocity, "tkiller")

    @property
    def max_speed(self):
        return TKILLER_SPEED

    def flock(self, sim: "Simulation"):
        target, distance = sim.nearest_cancer(self.position)
        if target is not None and distance < TKILLER_DETECT_RADIUS:
            desired = normalize(target.position-self.position)*self.max_speed
            self.apply_force(limit(desired-self.velocity, 3.0))
        else:
            self.apply_force(np.random.uniform(-1, 1, 3).astype(np.float32)*0.7)
        near = sim.tkiller_neighbors(self.position, 1.7)
        self.apply_force(0.55*self.separation(near, 1.7))


class Simulation:
    def __init__(self):
        self.cells: list[Agent] = []
        self.tkillers: list[TKiller] = []
        self.kd_all = self.kd_red = self.kd_cancer = self.kd_t = self.kd_physics = None
        self.all_items = self.red_items = self.cancer_items = []
        self.physics_items = []
        self.adhesion_bonds = {}
        self.reset()

    def random_position(self):
        return np.random.uniform(-0.48*WORLD, 0.48*WORLD).astype(np.float32)

    @staticmethod
    def random_velocity(scale=1.5):
        return np.random.uniform(-scale, scale, 3).astype(np.float32)

    def reset(self):
        self.cells = [Agent(self.random_position(), self.random_velocity(), "erythrocyte")
                      for _ in range(NUM_ERYTHROCYTES)]
        self.cells += [Agent(np.random.uniform(-2.2, 2.2, 3), self.random_velocity(2.0), "cancer")
                       for _ in range(NUM_CANCER)]
        self.tkillers = [TKiller(self.random_position(), self.random_velocity(2.0))
                         for _ in range(NUM_TKILLER)]
        self.adhesion_bonds = {}

    def rebuild_trees(self):
        self.all_items = list(self.cells)
        self.red_items = [c for c in self.cells if not c.cancer]
        self.cancer_items = [c for c in self.cells if c.cancer]
        self.kd_all = KDTree([a.position for a in self.all_items]) if self.all_items else None
        self.kd_red = KDTree([a.position for a in self.red_items]) if self.red_items else None
        self.kd_cancer = KDTree([a.position for a in self.cancer_items]) if self.cancer_items else None
        self.kd_t = KDTree([a.position for a in self.tkillers]) if self.tkillers else None
        self.physics_items = self.all_items + list(self.tkillers)
        self.kd_physics = (KDTree([a.position for a in self.physics_items])
                           if self.physics_items else None)

    @staticmethod
    def _bond_pair(a, b):
        """Devuelve (cáncer, eritrocito), o None para un contacto no adhesivo."""
        if a.kind == "cancer" and b.kind == "erythrocyte":
            return a, b
        if b.kind == "cancer" and a.kind == "erythrocyte":
            return b, a
        return None

    @staticmethod
    def _bond_key(cancer, erythrocyte):
        return id(cancer), id(erythrocyte)

    def _create_adhesion_if_close(self, a, b, distance):
        pair = self._bond_pair(a, b)
        if pair is None:
            return
        cancer, red = pair
        rest = cancer.collision_radius + red.collision_radius - COLLISION_SKIN
        if distance <= rest + ADHESION_CAPTURE_RANGE:
            key = self._bond_key(cancer, red)
            if key not in self.adhesion_bonds:
                self.adhesion_bonds[key] = {
                    "cancer": cancer,
                    "red": red,
                    "rest": rest,
                }

    def apply_adhesion_forces(self):
        """Mantiene contactos cáncer-eritrocito sin convertirlos en juntas rígidas."""
        broken = []
        for key, bond in self.adhesion_bonds.items():
            cancer, red = bond["cancer"], bond["red"]
            if (cancer not in self.cells or red not in self.cells or
                    cancer.kind != "cancer" or red.kind != "erythrocyte"):
                broken.append(key)
                continue

            delta = red.position - cancer.position
            distance = float(np.linalg.norm(delta))
            if distance < 1e-7 or distance > bond["rest"] + ADHESION_BREAK_RANGE:
                broken.append(key)
                continue

            normal = delta / distance
            relative_velocity = red.velocity - cancer.velocity
            separation_speed = float(np.dot(relative_velocity, normal))
            stretch = max(0.0, distance - bond["rest"])

            # Fuerza sobre el cáncer orientada hacia el eritrocito. El término
            # amortiguado crece si se están separando y disminuye al aproximarse.
            normal_force = max(0.0, ADHESION_STIFFNESS*stretch +
                               ADHESION_DAMPING*separation_speed)
            tangential_velocity = relative_velocity - separation_speed*normal
            force = normal_force*normal + ADHESION_TANGENTIAL_DRAG*tangential_velocity
            force = limit(force, ADHESION_MAX_FORCE)
            cancer.apply_force(force*cancer.inverse_mass)
            red.apply_force(-force*red.inverse_mass)

        for key in broken:
            self.adhesion_bonds.pop(key, None)

    def solve_collisions(self):
        """Resuelve contactos de las parejas cercanas devueltas por el KD-tree."""
        if self.kd_physics is None:
            return
        pairs = self.kd_physics.query_pairs(COLLISION_QUERY_RADIUS)
        half = WORLD*0.5

        for ia, ib in pairs:
            a, b = self.physics_items[ia], self.physics_items[ib]
            delta = b.position - a.position
            distance = float(np.linalg.norm(delta))
            minimum = a.collision_radius + b.collision_radius - COLLISION_SKIN
            self._create_adhesion_if_close(a, b, distance)

            if distance >= minimum:
                continue
            if distance < 1e-8:
                normal = normalize(b.velocity-a.velocity)
                if not np.any(normal):
                    normal = np.array((1.0, 0.0, 0.0), dtype=np.float32)
            else:
                normal = delta / distance
            penetration = minimum - distance
            inv_sum = a.inverse_mass + b.inverse_mass

            # Corrección posicional ponderada por masa.
            correction = normal * (COLLISION_CORRECTION*penetration/inv_sum)
            a.position -= correction*a.inverse_mass
            b.position += correction*b.inverse_mass

            # Impulso normal inelástico: cancela la velocidad de penetración.
            relative_velocity = b.velocity - a.velocity
            normal_speed = float(np.dot(relative_velocity, normal))
            if normal_speed < 0.0:
                impulse_size = (-(1.0 + COLLISION_RESTITUTION)*normal_speed/inv_sum)
                impulse = impulse_size*normal
                a.velocity -= impulse*a.inverse_mass
                b.velocity += impulse*b.inverse_mass

                tangent = relative_velocity - normal_speed*normal
                tangent_length = float(np.linalg.norm(tangent))
                if tangent_length > 1e-7:
                    friction_impulse = min(COLLISION_FRICTION*impulse_size,
                                           tangent_length/inv_sum) * (tangent/tangent_length)
                    a.velocity += friction_impulse*a.inverse_mass
                    b.velocity -= friction_impulse*b.inverse_mass

            a.position[:] = np.clip(a.position, -half, half)
            b.position[:] = np.clip(b.position, -half, half)

    @staticmethod
    def _neighbors(tree, items, point, radius, exclude=None):
        if tree is None:
            return []
        return [items[i] for i in tree.query_ball_point(point, radius) if items[i] is not exclude]

    @staticmethod
    def _nearest(tree, items, point):
        if tree is None or not items:
            return None, math.inf
        distance, index = tree.query(point, k=1)
        return items[int(index)], float(distance)

    def all_neighbors(self, p, r, exclude=None):
        return self._neighbors(self.kd_all, self.all_items, p, r, exclude)

    def erythrocyte_neighbors(self, p, r, exclude=None):
        return self._neighbors(self.kd_red, self.red_items, p, r, exclude)

    def cancer_neighbors(self, p, r, exclude=None):
        return self._neighbors(self.kd_cancer, self.cancer_items, p, r, exclude)

    def tkiller_neighbors(self, p, r, exclude=None):
        return self._neighbors(self.kd_t, self.tkillers, p, r, exclude)

    def nearest_erythrocyte(self, p):
        return self._nearest(self.kd_red, self.red_items, p)

    def nearest_cancer(self, p):
        return self._nearest(self.kd_cancer, self.cancer_items, p)

    def add(self, kind, position):
        velocity = self.random_velocity(1.7)
        if kind == "tkiller":
            self.tkillers.append(TKiller(position, velocity))
        else:
            self.cells.append(Agent(position, velocity, kind))

    def update(self, dt):
        self.rebuild_trees()
        for a in self.cells + self.tkillers:
            a.flock(self)
        self.apply_adhesion_forces()
        for a in self.cells + self.tkillers:
            a.integrate(dt)

        # La lista de parejas procede del único KD-tree físico del frame. Se
        # resuelve después de integrar para corregir cualquier penetración nueva.
        self.solve_collisions()

        # Infección escalada por dt: comportamiento estable aunque cambien los FPS.
        p = 1.0 - math.exp(-INFECTION_RATE*dt)
        for red in list(self.red_items):
            if self.cancer_neighbors(red.position, INFECTION_RADIUS) and random.random() < p:
                red.kind = "cancer"

        killed = set()
        for killer in self.tkillers:
            for cancer in self.cancer_neighbors(killer.position, TKILLER_KILL_RADIUS):
                if cancer not in killed:
                    killed.add(cancer)
                    break
        if killed:
            self.cells = [c for c in self.cells if c not in killed]
            self.adhesion_bonds = {
                key: bond for key, bond in self.adhesion_bonds.items()
                if bond["cancer"] not in killed
            }


# Render

VERTEX_SHADER = """
#version 330
in vec3 in_position;
in vec3 in_normal;
in vec2 in_uv;
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
out vec3 world_position;
out vec3 world_normal;
out vec2 uv;
void main() {
    vec4 wp = model * vec4(in_position, 1.0);
    world_position = wp.xyz;
    world_normal = normalize(mat3(model) * in_normal);
    uv = in_uv;
    gl_Position = projection * view * wp;
}
"""

FRAGMENT_SHADER = """
#version 330
uniform sampler2D albedo_map;
uniform vec3 camera_position;
uniform vec3 light_position;
uniform float bump_strength;
uniform float roughness;
uniform vec3 tint;
in vec3 world_position;
in vec3 world_normal;
in vec2 uv;
out vec4 frag_color;

float luminance(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    vec2 texel = 1.0 / vec2(textureSize(albedo_map, 0));
    float gx = luminance(texture(albedo_map, uv + vec2(texel.x, 0)).rgb)
             - luminance(texture(albedo_map, uv - vec2(texel.x, 0)).rgb);
    float gy = luminance(texture(albedo_map, uv + vec2(0, texel.y)).rgb)
             - luminance(texture(albedo_map, uv - vec2(0, texel.y)).rgb);

    vec3 n0 = normalize(world_normal);
    vec3 ref = abs(n0.y) < 0.9 ? vec3(0,1,0) : vec3(1,0,0);
    vec3 tangent = normalize(cross(ref, n0));
    vec3 bitangent = cross(n0, tangent);
    vec3 n = normalize(n0 - bump_strength*(gx*tangent + gy*bitangent));

    vec3 base = pow(texture(albedo_map, uv).rgb, vec3(2.2)) * tint;
    vec3 l = normalize(light_position - world_position);
    vec3 v = normalize(camera_position - world_position);
    vec3 h = normalize(l + v);
    float diffuse = max(dot(n, l), 0.0);
    float spec_power = mix(70.0, 8.0, roughness);
    float specular = pow(max(dot(n, h), 0.0), spec_power) * (1.0-0.72*roughness);
    float rim = pow(1.0-max(dot(n, v), 0.0), 3.0);
    vec3 color = base*(0.20 + 0.92*diffuse) + vec3(specular) + 0.14*base*rim;
    frag_color = vec4(pow(color, vec3(1.0/2.2)), 1.0);
}
"""

LINE_VERTEX = """
#version 330
in vec3 in_position;
uniform mat4 view;
uniform mat4 projection;
void main() { gl_Position = projection * view * vec4(in_position, 1.0); }
"""

LINE_FRAGMENT = """
#version 330
uniform vec4 color;
out vec4 frag_color;
void main() { frag_color = color; }
"""


class Renderer:
    def __init__(self, ctx: moderngl.Context):
        self.ctx = ctx
        self.program = ctx.program(vertex_shader=VERTEX_SHADER, fragment_shader=FRAGMENT_SHADER)
        self.line_program = ctx.program(vertex_shader=LINE_VERTEX, fragment_shader=LINE_FRAGMENT)
        self.meshes = {
            "erythrocyte": self._upload_mesh(*make_erythrocyte()),
            "tkiller": self._upload_mesh(*make_uv_sphere("tkiller")),
            "cancer": self._upload_mesh(*make_uv_sphere("cancer")),
        }
        self.textures = {
            "erythrocyte": self._load_texture("erythrocyte_albedo.png"),
            "tkiller": self._load_texture("tkiller_albedo.png"),
            "cancer": self._load_texture("cancer_albedo.png"),
        }
        self.material = {
            "erythrocyte": (2.0, 0.48, (1.00, 0.92, 0.92)),
            "tkiller": (2.8, 0.68, (0.94, 0.97, 1.00)),
            "cancer": (3.7, 0.86, (1.00, 1.00, 0.90)),
        }
        self.grid_vao = self._make_grid()

    def _upload_mesh(self, vertices, indices):
        vbo = self.ctx.buffer(vertices.tobytes())
        ibo = self.ctx.buffer(indices.astype("u4").tobytes())
        vao = self.ctx.vertex_array(
            self.program,
            [(vbo, "3f 3f 2f", "in_position", "in_normal", "in_uv")],
            index_buffer=ibo,
            index_element_size=4,
        )
        return vao, vbo, ibo

    def _load_texture(self, filename):
        path = ASSET_DIR / filename
        if not path.exists():
            raise FileNotFoundError(f"No se encontró la textura: {path}")
        image = Image.open(path).convert("RGB").transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        texture = self.ctx.texture(image.size, 3, image.tobytes())
        texture.filter = (moderngl.LINEAR_MIPMAP_LINEAR, moderngl.LINEAR)
        texture.repeat_x = texture.repeat_y = True
        texture.build_mipmaps()
        return texture

    def _make_grid(self):
        hx, hy, hz = WORLD*0.5
        vertices = []
        # Grilla en los tres planos posteriores del volumen.
        for x in np.linspace(-hx, hx, 17):
            vertices += [(x, -hy, -hz), (x, hy, -hz)]
            vertices += [(x, -hy, -hz), (x, -hy, hz)]
        for y in np.linspace(-hy, hy, 12):
            vertices += [(-hx, y, -hz), (hx, y, -hz)]
            vertices += [(-hx, y, -hz), (-hx, y, hz)]
        for z in np.linspace(-hz, hz, 10):
            vertices += [(-hx, -hy, z), (hx, -hy, z)]
            vertices += [(-hx, -hy, z), (-hx, hy, z)]
        vbo = self.ctx.buffer(np.asarray(vertices, dtype="f4").tobytes())
        return self.ctx.vertex_array(self.line_program, [(vbo, "3f", "in_position")])

    def draw(self, sim, view, projection, camera_position, show_grid=True):
        self.ctx.enable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)
        self.ctx.clear(0.012, 0.020, 0.030, 1.0, depth=1.0)
        upload_matrix(self.program["view"], view)
        upload_matrix(self.program["projection"], projection)
        self.program["camera_position"].value = tuple(camera_position)
        self.program["light_position"].value = (8.0, 14.0, 18.0)
        self.program["albedo_map"].value = 0

        for agent in sim.cells + sim.tkillers:
            kind = agent.kind
            bump, roughness, tint = self.material[kind]
            self.program["bump_strength"].value = bump
            self.program["roughness"].value = roughness
            self.program["tint"].value = tint
            upload_matrix(self.program["model"], agent.model_matrix())
            self.textures[kind].use(0)
            self.meshes[kind][0].render(moderngl.TRIANGLES)

        if show_grid:
            self.ctx.disable(moderngl.CULL_FACE)
            upload_matrix(self.line_program["view"], view)
            upload_matrix(self.line_program["projection"], projection)
            self.line_program["color"].value = (0.10, 0.38, 0.48, 0.28)
            self.grid_vao.render(moderngl.LINES)


# Ventana, cámara e interacción

config = pyglet.gl.Config(double_buffer=True, depth_size=24, major_version=3, minor_version=3)
window = pyglet.window.Window(WIDTH, HEIGHT, "CellSwarm 3D — respuesta inmune", config=config, resizable=True)
ctx = moderngl.create_context()
renderer = Renderer(ctx)
simulation = Simulation()

camera_target = np.zeros(3, dtype=np.float32)
camera_yaw = math.radians(38)
camera_pitch = math.radians(24)
camera_distance = 39.0
cursor_mode = None
show_grid = True
paused = False

ui_batch = pyglet.graphics.Batch()
hud = pyglet.text.Label(
    "", x=16, y=HEIGHT-16, anchor_x="left", anchor_y="top",
    font_name="Courier New", font_size=11, color=(215, 240, 250, 255),
    multiline=True, width=390, batch=ui_batch,
)
help_label = pyglet.text.Label(
    "Arrastrar: orbitar  |  Rueda: zoom  |  H/C/W + clic: insertar  |  G: grilla  |  P: pausa",
    x=WIDTH//2, y=13, anchor_x="center", anchor_y="bottom",
    font_name="Arial", font_size=10, color=(165, 190, 200, 230), batch=ui_batch,
)
fps = pyglet.window.FPSDisplay(window)


def camera_position():
    cp = math.cos(camera_pitch)
    direction = np.array((cp*math.cos(camera_yaw), math.sin(camera_pitch),
                          cp*math.sin(camera_yaw)), dtype=np.float32)
    return camera_target + camera_distance*direction


def matrices():
    eye = camera_position()
    view = look_at(eye, camera_target, np.array((0, 1, 0), dtype=np.float32))
    projection = perspective(math.radians(52), window.width/max(window.height, 1), 0.1, 160.0)
    return view, projection, eye


def insertion_point(x, y):
    view, projection, eye = matrices()
    ndc_x = 2.0*x/window.width - 1.0
    ndc_y = 2.0*y/window.height - 1.0
    inv = np.linalg.inv(projection @ view)
    near = inv @ np.array((ndc_x, ndc_y, -1, 1), dtype=np.float32)
    far = inv @ np.array((ndc_x, ndc_y, 1, 1), dtype=np.float32)
    near, far = near[:3]/near[3], far[:3]/far[3]
    ray = normalize(far-near)
    plane_normal = normalize(camera_target-eye)
    denom = float(np.dot(ray, plane_normal))
    t = float(np.dot(camera_target-near, plane_normal)/denom) if abs(denom) > 1e-7 else 0.0
    return np.clip(near + max(t, 0.0)*ray, -0.48*WORLD, 0.48*WORLD).astype(np.float32)


def update_hud():
    red = sum(not c.cancer for c in simulation.cells)
    cancer = sum(c.cancer for c in simulation.cells)
    mode = {None: "cámara", "erythrocyte": "eritrocito", "cancer": "cáncer",
            "tkiller": "T-killer"}[cursor_mode]
    hud.text = (f"[ CELLSWARM 3D ]\n\n"
                f"Eritrocitos : {red}\nCáncer      : {cancer}\nT-killer    : {len(simulation.tkillers)}\n\n"
                f"Adhesiones  : {len(simulation.adhesion_bonds)}\n\n"
                f"Modo        : {mode}\nEstado      : {'PAUSA' if paused else 'activo'}")


def update(dt):
    if not paused:
        simulation.update(min(dt, 0.04))
    update_hud()


@window.event
def on_draw():
    view, projection, eye = matrices()
    renderer.draw(simulation, view, projection, eye, show_grid)
    ctx.disable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)
    ui_batch.draw()
    fps.draw()


@window.event
def on_resize(width, height):
    ctx.viewport = (0, 0, width, height)
    hud.y = height-16
    help_label.x, help_label.y = width//2, 13
    return pyglet.event.EVENT_HANDLED


@window.event
def on_mouse_drag(x, y, dx, dy, buttons, modifiers):
    global camera_yaw, camera_pitch
    if buttons & mouse.RIGHT or (buttons & mouse.LEFT and cursor_mode is None):
        camera_yaw -= dx*0.008
        camera_pitch = float(np.clip(camera_pitch + dy*0.008, -1.42, 1.42))


@window.event
def on_mouse_scroll(x, y, scroll_x, scroll_y):
    global camera_distance
    camera_distance = float(np.clip(camera_distance*math.exp(-0.10*scroll_y), 9.0, 85.0))


@window.event
def on_mouse_press(x, y, button, modifiers):
    if button == mouse.LEFT and cursor_mode is not None:
        simulation.add(cursor_mode, insertion_point(x, y))


@window.event
def on_key_press(symbol, modifiers):
    global cursor_mode, show_grid, paused
    modes = {key.H: "erythrocyte", key.C: "cancer", key.W: "tkiller"}
    if symbol in modes:
        cursor_mode = None if cursor_mode == modes[symbol] else modes[symbol]
    elif symbol == key.G:
        show_grid = not show_grid
    elif symbol == key.P:
        paused = not paused
    elif symbol == key.R:
        simulation.reset()
    elif symbol == key.ESCAPE:
        if cursor_mode is None:
            window.close()
        else:
            cursor_mode = None


update_hud()
pyglet.clock.schedule_interval(update, 1/60)
pyglet.app.run()
