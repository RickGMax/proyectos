"""Modelo de la red de impulsos nerviosos a partir de grafos.

Los vértices representan las neuronas y las aristas sus conexiones. La idea
es observar cómo se propaga un pulso, qué pasa cuando encuentra ciclos y
cómo se relaciona esto con Dijkstra y Kruskal. Se puede usar una grilla o
una distribución espacial. La parte gráfica queda en el otro archivo.
"""

import random
import math
import statistics
import heapq
from dataclasses import dataclass, field
from numbers import Integral


def _validar_dt(dt):
    """El tiempo avanza en segundos; no puede retroceder ni ser infinito."""
    if not math.isfinite(dt) or dt < 0:
        raise ValueError("dt debe ser un número finito mayor o igual que cero")


# ---------------------------------------------------------------------------
# Parámetros de la simulación (tiempos en segundos)
# ---------------------------------------------------------------------------
TIEMPO_VIAJE_SINAPSIS = 0.45      # cuánto tarda un impulso en recorrer una arista
TIEMPO_DISPARO = 0.18             # cuánto dura la neurona "encendida" (potencial de acción)
TIEMPO_REFRACTARIO = 0.90         # bloquea reactivaciones rápidas y el retorno por una arista
RETARDO_SINAPTICO = 0.05          # espera entre la llegada del pulso y el disparo


class EstadoNeurona:
    REPOSO = "reposo"
    DISPARANDO = "disparando"
    REFRACTARIA = "refractaria"


@dataclass
class Neurona:
    """Vértice con una posición, sus vecinos y un estado de activación."""

    id: int
    x: float
    y: float
    z: float = 0.0
    estado: str = EstadoNeurona.REPOSO
    reloj_estado: float = 0.0   # tiempo acumulado en el estado actual
    vecinos: list = field(default_factory=list)  # ids de neuronas conectadas
    tiempo_disparo: float = TIEMPO_DISPARO
    tiempo_refractario: float = TIEMPO_REFRACTARIO
    # Una onda concreta solo puede activar una vez a cada neurona. Esto evita
    # que el mismo impulso recorra un ciclo y regrese cuando terminó la
    # refracción, generando una propagación sin fin.
    ondas_procesadas: set = field(default_factory=set, repr=False)

    def actualizar(self, dt):
        """Pasa de disparo a refracción y luego a reposo según el tiempo."""
        _validar_dt(dt)
        if self.estado == EstadoNeurona.REPOSO:
            return
        self.reloj_estado += dt
        if self.estado == EstadoNeurona.DISPARANDO and self.reloj_estado >= self.tiempo_disparo:
            self.estado = EstadoNeurona.REFRACTARIA
            # Conservamos el tiempo sobrante. Un paso largo puede completar
            # tanto el disparo como el período refractario.
            self.reloj_estado -= self.tiempo_disparo
        if (
            self.estado == EstadoNeurona.REFRACTARIA
            and self.reloj_estado >= self.tiempo_refractario
        ):
            self.estado = EstadoNeurona.REPOSO
            self.reloj_estado = 0.0

    def disparar(self):
        """Activa el soma. Si ya está disparando o refractaria, no reinicia."""
        if self.estado == EstadoNeurona.REPOSO:
            self.estado = EstadoNeurona.DISPARANDO
            self.reloj_estado = 0.0
            return True
        return False

    def puede_recibir_impulso(self):
        """Solo una neurona completamente en reposo puede aceptar otra onda."""
        return self.estado == EstadoNeurona.REPOSO

    def puede_propagar(self):
        """Alias conservado para código externo de versiones anteriores."""
        return self.puede_recibir_impulso()


@dataclass
class ImpulsoEnViaje:
    """Pulso que recorre una arista entre dos neuronas del modelo."""
    origen: int
    destino: int
    id_onda: int
    progreso: float = 0.0   # 0.0 -> 1.0 a lo largo de la arista
    duracion: float = TIEMPO_VIAJE_SINAPSIS
    # En una ruta dirigida contiene los nodos que faltan después de ``destino``.
    # Si la tupla está vacía, este es el último tramo. ``dirigido`` distingue
    # ese recorrido de una onda normal que se propaga por los vecinos.
    camino_restante: tuple = field(default_factory=tuple)
    dirigido: bool = False

    def __post_init__(self):
        if not math.isfinite(self.duracion) or self.duracion <= 0:
            raise ValueError("la duración del impulso debe ser finita y positiva")

    def actualizar(self, dt):
        _validar_dt(dt)
        self.progreso += dt / self.duracion
        return self.progreso >= 1.0


@dataclass
class EventoDisparo:
    """Activación pendiente durante el retardo de transmisión sináptica."""

    destino: int
    tiempo_restante: float
    id_onda: int
    origen: int
    camino_restante: tuple = field(default_factory=tuple)
    dirigido: bool = False


class RedNeuronal:
    """Grafo no dirigido con propagación de pulsos y algoritmos de caminos.

    Cada neurona guarda una lista de vecinos. Las aristas se guardan una
    sola vez, ordenando los ids de sus extremos. Todos los tiempos están
    en segundos y las distancias usan las unidades de la escena.
    """

    def __init__(self, filas, columnas, espaciado_x, espaciado_y, jitter=0.0,
                 prob_conexion_diagonal=0.15, semilla=None, capas=1,
                 espaciado_z=None, jitter_z=None,
                 prob_conexion_entre_capas=0.35,
                 topologia="grilla",
                 expansion_espacial=1.0,
                 separacion_minima=0.35,
                 vecinos_minimos=2,
                 conexiones_extra_por_nodo=2,
                 prob_conexion_larga=0.04,
                 tiempo_segun_distancia=False,
                 tiempo_viaje_sinapsis=TIEMPO_VIAJE_SINAPSIS,
                 tiempo_disparo=TIEMPO_DISPARO,
                 tiempo_refractario=TIEMPO_REFRACTARIO,
                 retardo_sinaptico=RETARDO_SINAPTICO):
        for nombre, valor in (("filas", filas), ("columnas", columnas), ("capas", capas)):
            if isinstance(valor, bool) or not isinstance(valor, Integral) or valor <= 0:
                raise ValueError(f"{nombre} debe ser un entero mayor que cero")
        for nombre, valor in (
            ("tiempo_viaje_sinapsis", tiempo_viaje_sinapsis),
            ("tiempo_disparo", tiempo_disparo),
            ("espaciado_x", espaciado_x),
            ("espaciado_y", espaciado_y),
        ):
            if not math.isfinite(valor) or valor <= 0:
                raise ValueError(f"{nombre} debe ser finito y mayor que cero")
        if espaciado_z is not None and (not math.isfinite(espaciado_z) or espaciado_z <= 0):
            raise ValueError("espaciado_z debe ser finito y mayor que cero")
        for nombre, valor in (
            ("tiempo_refractario", tiempo_refractario),
            ("retardo_sinaptico", retardo_sinaptico),
            ("jitter", jitter),
            ("separacion_minima", separacion_minima),
        ):
            if not math.isfinite(valor) or valor < 0:
                raise ValueError(f"{nombre} debe ser finito y no negativo")
        if jitter_z is not None and (not math.isfinite(jitter_z) or jitter_z < 0):
            raise ValueError("jitter_z debe ser finito y no negativo")
        if topologia not in {"grilla", "espacial"}:
            raise ValueError("topologia debe ser 'grilla' o 'espacial'")
        if not math.isfinite(expansion_espacial) or expansion_espacial <= 0:
            raise ValueError("expansion_espacial debe ser finita y positiva")
        for nombre, valor, minimo in (
            ("vecinos_minimos", vecinos_minimos, 1),
            ("conexiones_extra_por_nodo", conexiones_extra_por_nodo, 0),
        ):
            if isinstance(valor, bool) or not isinstance(valor, Integral) or valor < minimo:
                raise ValueError(f"{nombre} debe ser un entero mayor o igual que {minimo}")
        for nombre, valor in (
            ("prob_conexion_diagonal", prob_conexion_diagonal),
            ("prob_conexion_entre_capas", prob_conexion_entre_capas),
            ("prob_conexion_larga", prob_conexion_larga),
        ):
            if not math.isfinite(valor) or not 0 <= valor <= 1:
                raise ValueError(f"{nombre} debe estar entre 0 y 1")

        self.filas = filas
        self.columnas = columnas
        self.capas = capas
        self.topologia = topologia
        self._rng = random.Random(semilla)
        self.tiempo_viaje_sinapsis = tiempo_viaje_sinapsis
        self.tiempo_segun_distancia = tiempo_segun_distancia
        self.tiempo_disparo = tiempo_disparo
        self.tiempo_refractario = tiempo_refractario
        self.retardo_sinaptico = retardo_sinaptico
        self.neuronas = {}        # id -> Neurona
        self.aristas = set()      # set de tuplas (min_id, max_id) -> sinapsis únicas
        self.impulsos = []        # lista de ImpulsoEnViaje activos
        self.eventos_disparo = []  # cola de EventoDisparo pendientes
        self._siguiente_id_onda = 0
        self.impulsos_bloqueados = 0
        self.ultima_ruta_minima = []
        self.ultimo_origen_ruta = None
        self.ultimo_destino_ruta = None

        if espaciado_z is None:
            espaciado_z = (espaciado_x + espaciado_y) / 2
        if jitter_z is None:
            jitter_z = jitter

        if topologia == "espacial":
            self._construir_red_espacial(
                espaciado_x=espaciado_x,
                espaciado_y=espaciado_y,
                espaciado_z=espaciado_z,
                expansion=expansion_espacial,
                separacion_minima=separacion_minima,
                vecinos_minimos=vecinos_minimos,
                conexiones_extra_por_nodo=conexiones_extra_por_nodo,
                prob_conexion_larga=prob_conexion_larga,
            )
        else:
            self._construir_grilla(
                espaciado_x,
                espaciado_y,
                espaciado_z,
                jitter,
                jitter_z,
                prob_conexion_diagonal,
                prob_conexion_entre_capas,
            )

        longitudes = [self._distancia_entre(a, b) for a, b in self.aristas]
        self.longitud_sinapsis_referencia = (
            statistics.median(longitudes) if longitudes else 1.0
        )

    # -- construcción del grafo -------------------------------------------------
    def _id(self, *indices):
        """Obtiene el id de una celda.

        Acepta ``(fila, columna)`` para conservar compatibilidad con el modelo
        2D, o ``(capa, fila, columna)`` para la grilla 3D.
        """
        if len(indices) == 2:
            capa = 0
            fila, col = indices
        elif len(indices) == 3:
            capa, fila, col = indices
        else:
            raise TypeError("_id espera (fila, col) o (capa, fila, col)")
        return capa * self.filas * self.columnas + fila * self.columnas + col

    def _construir_grilla(self, esp_x, esp_y, esp_z, jitter_xy, jitter_z,
                          prob_diag, prob_entre_capas):
        # El jitter desplaza un poco cada vértice para variar la grilla.
        for k in range(self.capas):
            for f in range(self.filas):
                for c in range(self.columnas):
                    nid = self._id(k, f, c)
                    jx = self._rng.uniform(-jitter_xy, jitter_xy)
                    jy = self._rng.uniform(-jitter_xy, jitter_xy)
                    jz = self._rng.uniform(-jitter_z, jitter_z) if self.capas > 1 else 0.0
                    x = c * esp_x + jx
                    y = f * esp_y + jy
                    z = k * esp_z + jz
                    self.neuronas[nid] = Neurona(
                        id=nid,
                        x=x,
                        y=y,
                        z=z,
                        tiempo_disparo=self.tiempo_disparo,
                        tiempo_refractario=self.tiempo_refractario,
                    )

        # 2. Conexiones ortogonales y diagonales dentro de cada capa.
        for k in range(self.capas):
            for f in range(self.filas):
                for c in range(self.columnas):
                    nid = self._id(k, f, c)
                    if c + 1 < self.columnas:
                        self._agregar_arista(nid, self._id(k, f, c + 1))
                    if f + 1 < self.filas:
                        self._agregar_arista(nid, self._id(k, f + 1, c))

                    diagonales = []
                    if f + 1 < self.filas and c + 1 < self.columnas:
                        diagonales.append(self._id(k, f + 1, c + 1))
                    if f + 1 < self.filas and c - 1 >= 0:
                        diagonales.append(self._id(k, f + 1, c - 1))
                    for v in diagonales:
                        if self._rng.random() < prob_diag:
                            self._agregar_arista(nid, v)

                    # Las conexiones en profundidad convierten las capas en una
                    # sola red 3D. No son obligatorias para evitar un cubo rígido.
                    if k + 1 < self.capas and self._rng.random() < prob_entre_capas:
                        self._agregar_arista(nid, self._id(k + 1, f, c))

                    # Algunas sinapsis oblicuas entre capas aportan rutas 3D.
                    if k + 1 < self.capas:
                        candidatos_3d = []
                        if c + 1 < self.columnas:
                            candidatos_3d.append(self._id(k + 1, f, c + 1))
                        if f + 1 < self.filas:
                            candidatos_3d.append(self._id(k + 1, f + 1, c))
                        for v in candidatos_3d:
                            if self._rng.random() < prob_entre_capas * 0.22:
                                self._agregar_arista(nid, v)

    def _construir_red_espacial(
        self,
        espaciado_x,
        espaciado_y,
        espaciado_z,
        expansion,
        separacion_minima,
        vecinos_minimos,
        conexiones_extra_por_nodo,
        prob_conexion_larga,
    ):
        """Crea una nube 3D irregular y dispersa, sin filas ni capas visibles.

        Primero se generan posiciones aleatorias con una distancia mínima. Luego
        se usa un árbol de expansión mínima para garantizar que todo el grafo
        quede conectado. Finalmente se añaden conexiones locales y unos pocos
        atajos largos, produciendo ciclos y longitudes variadas sin formar una
        malla compacta.
        """
        cantidad = self.filas * self.columnas * self.capas
        ancho = max(espaciado_x, (self.columnas - 1) * espaciado_x) * expansion
        alto = max(espaciado_y, (self.filas - 1) * espaciado_y) * expansion
        profundidad = (
            max(espaciado_z, (self.capas - 1) * espaciado_z) * expansion
            if self.capas > 1 else 0.0
        )
        distancia_minima = separacion_minima * min(
            espaciado_x,
            espaciado_y,
            espaciado_z if self.capas > 1 else min(espaciado_x, espaciado_y),
        )

        posiciones = []
        intentos_maximos = max(300, cantidad * 80)
        intentos = 0
        while len(posiciones) < cantidad and intentos < intentos_maximos:
            intentos += 1
            candidato = (
                self._rng.uniform(0.0, ancho),
                self._rng.uniform(0.0, alto),
                self._rng.uniform(0.0, profundidad) if self.capas > 1 else 0.0,
            )
            if all(
                math.dist(candidato, existente) >= distancia_minima
                for existente in posiciones
            ):
                posiciones.append(candidato)

        # Si el rechazo geométrico se vuelve demasiado exigente, se completa la
        # nube sin fallar. En tamaños normales este bloque rara vez se utiliza.
        while len(posiciones) < cantidad:
            posiciones.append((
                self._rng.uniform(0.0, ancho),
                self._rng.uniform(0.0, alto),
                self._rng.uniform(0.0, profundidad) if self.capas > 1 else 0.0,
            ))

        for nid, (x, y, z) in enumerate(posiciones):
            self.neuronas[nid] = Neurona(
                id=nid,
                x=x,
                y=y,
                z=z,
                tiempo_disparo=self.tiempo_disparo,
                tiempo_refractario=self.tiempo_refractario,
            )

        pares = []
        for a in range(cantidad):
            for b in range(a + 1, cantidad):
                pares.append((math.dist(posiciones[a], posiciones[b]), a, b))
        pares.sort()

        # Kruskal: esqueleto conectado con el menor largo total posible.
        padres = list(range(cantidad))
        rangos = [0] * cantidad

        def buscar(nodo):
            while padres[nodo] != nodo:
                padres[nodo] = padres[padres[nodo]]
                nodo = padres[nodo]
            return nodo

        def unir(a, b):
            raiz_a, raiz_b = buscar(a), buscar(b)
            if raiz_a == raiz_b:
                return False
            if rangos[raiz_a] < rangos[raiz_b]:
                raiz_a, raiz_b = raiz_b, raiz_a
            padres[raiz_b] = raiz_a
            if rangos[raiz_a] == rangos[raiz_b]:
                rangos[raiz_a] += 1
            return True

        for _, a, b in pares:
            if unir(a, b):
                self._agregar_arista(a, b)
                if len(self.aristas) == cantidad - 1:
                    break

        # Evita hojas excesivas: cada nodo obtiene al menos vecinos_minimos.
        vecinos_ordenados = {nid: [] for nid in range(cantidad)}
        for distancia, a, b in pares:
            vecinos_ordenados[a].append((distancia, b))
            vecinos_ordenados[b].append((distancia, a))
        objetivo = min(vecinos_minimos, max(1, cantidad - 1))
        for nid in range(cantidad):
            for _, vecino in vecinos_ordenados[nid]:
                if len(self.neuronas[nid].vecinos) >= objetivo:
                    break
                self._agregar_arista(nid, vecino)

        # Conexiones locales adicionales: aumentan los ciclos sin uniformar la red.
        for nid in range(cantidad):
            candidatos = [
                vecino for _, vecino in vecinos_ordenados[nid]
                if vecino not in self.neuronas[nid].vecinos
            ][:max(0, conexiones_extra_por_nodo * 3)]
            self._rng.shuffle(candidatos)
            for vecino in candidatos[:conexiones_extra_por_nodo]:
                if self._rng.random() < 0.58:
                    self._agregar_arista(nid, vecino)

        # Atajos entre regiones alejadas. Se toma el 45 % más largo de los pares
        # para que estas conexiones sean visualmente distintas de las locales.
        inicio_largos = int(len(pares) * 0.55)
        candidatos_largos = pares[inicio_largos:]
        self._rng.shuffle(candidatos_largos)
        cantidad_largas = round(cantidad * prob_conexion_larga)
        agregadas = 0
        if cantidad_largas > 0:
            for _, a, b in candidatos_largos:
                if (min(a, b), max(a, b)) not in self.aristas:
                    self._agregar_arista(a, b)
                    agregadas += 1
                    if agregadas >= cantidad_largas:
                        break

    def _agregar_arista(self, a, b):
        clave = (min(a, b), max(a, b))
        if clave in self.aristas:
            return
        self.aristas.add(clave)
        self.neuronas[a].vecinos.append(b)
        self.neuronas[b].vecinos.append(a)

    def _distancia_entre(self, a, b):
        na, nb = self.neuronas[a], self.neuronas[b]
        return math.dist((na.x, na.y, na.z), (nb.x, nb.y, nb.z))

    # -- algoritmos de grafos ------------------------------------------------
    def camino_mas_corto(self, origen, destino):
        """Calcula con Dijkstra el camino de menor longitud geométrica.

        El costo de una sinapsis es su largo euclidiano en el espacio 3D. La
        función retorna una lista desde ``origen`` hasta ``destino`` o una
        lista vacía si no existe conexión.
        """
        if origen not in self.neuronas or destino not in self.neuronas:
            raise KeyError("origen y destino deben ser ids de neuronas válidas")
        if origen == destino:
            return [origen]

        distancias = {origen: 0.0}
        anteriores = {}
        cola = [(0.0, origen)]

        while cola:
            distancia_actual, actual = heapq.heappop(cola)
            if distancia_actual > distancias.get(actual, math.inf):
                continue
            if actual == destino:
                break

            for vecino in self.neuronas[actual].vecinos:
                nueva_distancia = (
                    distancia_actual + self._distancia_entre(actual, vecino)
                )
                if nueva_distancia < distancias.get(vecino, math.inf):
                    distancias[vecino] = nueva_distancia
                    anteriores[vecino] = actual
                    heapq.heappush(cola, (nueva_distancia, vecino))

        if destino not in distancias:
            return []

        camino = [destino]
        while camino[-1] != origen:
            camino.append(anteriores[camino[-1]])
        camino.reverse()
        return camino

    def arbol_expansion_minima(self):
        """Obtiene con Kruskal las conexiones de menor longitud total.

        Si la red está desconectada, retorna un bosque: un árbol por cada
        componente. No agrega conexiones que no existan en el grafo.
        """
        padres = {nid: nid for nid in self.neuronas}
        rangos = {nid: 0 for nid in self.neuronas}

        def buscar(nodo):
            while padres[nodo] != nodo:
                padres[nodo] = padres[padres[nodo]]
                nodo = padres[nodo]
            return nodo

        def unir(a, b):
            raiz_a, raiz_b = buscar(a), buscar(b)
            if raiz_a == raiz_b:
                return False
            if rangos[raiz_a] < rangos[raiz_b]:
                raiz_a, raiz_b = raiz_b, raiz_a
            padres[raiz_b] = raiz_a
            if rangos[raiz_a] == rangos[raiz_b]:
                rangos[raiz_a] += 1
            return True

        arbol = set()
        aristas_ordenadas = sorted(
            (self._distancia_entre(a, b), a, b) for a, b in self.aristas
        )
        for _, a, b in aristas_ordenadas:
            if unir(a, b):
                arbol.add((min(a, b), max(a, b)))
                if len(arbol) == max(0, len(self.neuronas) - 1):
                    break
        return arbol

    # -- disparo / propagación ----------------------------------------------
    def lanzar_impulso_aleatorio(self):
        """Elige una neurona aleatoria en reposo y dispara desde ahí."""
        candidatos = [n for n in self.neuronas.values() if n.estado == EstadoNeurona.REPOSO]
        if not candidatos:
            candidatos = list(self.neuronas.values())
        origen = self._rng.choice(candidatos)
        self.disparar_neurona(origen.id)
        return origen.id

    def lanzar_impulso_por_ruta_minima(self):
        """Envía un impulso entre dos nodos aleatorios por su camino mínimo.

        A diferencia de una onda normal, este impulso no se bifurca: al llegar
        a cada neurona continúa únicamente hacia el siguiente nodo de la ruta.
        Retorna ``(origen, destino, camino)``.
        """
        ids = list(self.neuronas)
        if len(ids) < 2:
            raise ValueError("se necesitan al menos dos neuronas")
        origenes_disponibles = [
            nid for nid in ids
            if self.neuronas[nid].estado == EstadoNeurona.REPOSO
        ]
        origen = self._rng.choice(origenes_disponibles or ids)
        destino = self._rng.choice([nid for nid in ids if nid != origen])
        camino = self.camino_mas_corto(origen, destino)

        self.ultima_ruta_minima = camino
        self.ultimo_origen_ruta = origen
        self.ultimo_destino_ruta = destino
        if not camino:
            return origen, destino, camino

        id_onda = self._siguiente_id_onda
        self._siguiente_id_onda += 1
        neurona_origen = self.neuronas[origen]
        if not neurona_origen.disparar():
            return origen, destino, camino
        neurona_origen.ondas_procesadas.add(id_onda)

        if len(camino) > 1:
            self._enviar_siguiente_tramo(
                origen,
                camino[1],
                tuple(camino[2:]),
                id_onda,
            )
        return origen, destino, camino

    def disparar_neurona(self, nid, id_onda=None, origen=None):
        """Dispara ``nid`` e inicia o continúa una onda de propagación.

        Un disparo externo crea un ``id_onda`` nuevo. Los disparos recibidos
        conservan el identificador, de modo que una onda no puede activar dos
        veces la misma neurona aunque existan ciclos en el grafo.
        """
        neurona = self.neuronas[nid]
        if id_onda is None:
            id_onda = self._siguiente_id_onda
            self._siguiente_id_onda += 1

        if id_onda in neurona.ondas_procesadas:
            return False

        disparo_exitoso = neurona.disparar()
        if disparo_exitoso:
            neurona.ondas_procesadas.add(id_onda)
            self._propagar_desde(nid, id_onda, excluir_vecino=origen)
        return disparo_exitoso

    def _propagar_desde(self, nid, id_onda, excluir_vecino=None):
        """Envía el pulso hacia los vecinos disponibles de la neurona.

        No se vuelve por la sinapsis de entrada y tampoco se envía hacia una
        neurona que ya procesó esta misma onda.
        """
        origen = self.neuronas[nid]
        for vecino_id in origen.vecinos:
            if vecino_id == excluir_vecino:
                continue
            vecino = self.neuronas[vecino_id]
            if id_onda in vecino.ondas_procesadas:
                continue
            self.impulsos.append(
                ImpulsoEnViaje(
                    origen=nid,
                    destino=vecino_id,
                    id_onda=id_onda,
                    duracion=self._duracion_tramo(nid, vecino_id),
                )
            )

    def _duracion_tramo(self, origen, destino):
        """Ajusta el viaje por distancia usando la mediana como referencia.

        El factor se acota entre 0.45 y 3.2 para que los pulsos más cortos
        sigan siendo visibles y los más largos no demoren demasiado.
        """
        duracion = self.tiempo_viaje_sinapsis
        if self.tiempo_segun_distancia:
            factor = self._distancia_entre(origen, destino) / max(
                self.longitud_sinapsis_referencia, 1e-9
            )
            duracion *= max(0.45, min(3.2, factor))
        return duracion

    def _enviar_siguiente_tramo(
        self, origen, destino, camino_restante, id_onda
    ):
        self.impulsos.append(
            ImpulsoEnViaje(
                origen=origen,
                destino=destino,
                id_onda=id_onda,
                duracion=self._duracion_tramo(origen, destino),
                camino_restante=camino_restante,
                dirigido=True,
            )
        )

    def _disparar_en_ruta(
        self, nid, id_onda, origen, camino_restante
    ):
        neurona = self.neuronas[nid]
        if id_onda in neurona.ondas_procesadas or not neurona.disparar():
            return False
        neurona.ondas_procesadas.add(id_onda)
        if camino_restante:
            siguiente = camino_restante[0]
            self._enviar_siguiente_tramo(
                nid,
                siguiente,
                camino_restante[1:],
                id_onda,
            )
        return True

    def _evento_ya_pendiente(self, destino, id_onda):
        return any(
            evento.destino == destino and evento.id_onda == id_onda
            for evento in self.eventos_disparo
        )

    def _limpiar_ondas_finalizadas(self):
        """Libera el historial de ondas que ya no tienen actividad pendiente."""
        ondas_activas = {imp.id_onda for imp in self.impulsos}
        ondas_activas.update(evento.id_onda for evento in self.eventos_disparo)
        for neurona in self.neuronas.values():
            neurona.ondas_procesadas.intersection_update(ondas_activas)

    # -- loop de actualización ------------------------------------------------
    def actualizar(self, dt):
        """Avanza los estados, disparos pendientes y pulsos en viaje.

        Se usa un paso discreto: las llegadas se procesan en este paso y
        su retardo sináptico empieza a descontarse en el siguiente.
        """
        _validar_dt(dt)
        if dt == 0:
            return
        for n in self.neuronas.values():
            n.actualizar(dt)

        # actualizar eventos de disparo en cola (retardo sináptico)
        nuevos_eventos = []
        for evento in self.eventos_disparo:
            evento.tiempo_restante -= dt
            if evento.tiempo_restante <= 0:
                if evento.dirigido:
                    disparo_exitoso = self._disparar_en_ruta(
                        evento.destino,
                        evento.id_onda,
                        evento.origen,
                        evento.camino_restante,
                    )
                else:
                    disparo_exitoso = self.disparar_neurona(
                        evento.destino,
                        id_onda=evento.id_onda,
                        origen=evento.origen,
                    )
                if not disparo_exitoso:
                    self.impulsos_bloqueados += 1
            else:
                nuevos_eventos.append(evento)
        self.eventos_disparo = nuevos_eventos

        # actualizar impulsos viajando por las aristas
        impulsos_vivos = []
        for imp in self.impulsos:
            llego = imp.actualizar(dt)
            if llego:
                destino = self.neuronas[imp.destino]
                puede_recibir = destino.puede_recibir_impulso()
                onda_nueva = imp.id_onda not in destino.ondas_procesadas
                evento_nuevo = not self._evento_ya_pendiente(
                    imp.destino, imp.id_onda
                )
                if puede_recibir and onda_nueva and evento_nuevo:
                    # Al llegar, no disparamos inmediatamente: encolamos con un
                    # pequeño retardo para representar la transmisión sináptica.
                    self.eventos_disparo.append(
                        EventoDisparo(
                            destino=imp.destino,
                            tiempo_restante=self.retardo_sinaptico,
                            id_onda=imp.id_onda,
                            origen=imp.origen,
                            camino_restante=imp.camino_restante,
                            dirigido=imp.dirigido,
                        )
                    )
                else:
                    # Si está disparando o refractaria, el impulso se absorbe.
                    self.impulsos_bloqueados += 1
            else:
                impulsos_vivos.append(imp)
        self.impulsos = impulsos_vivos
        self._limpiar_ondas_finalizadas()

    # -- utilidades ------------------------------------------------------------
    def num_neuronas(self):
        return len(self.neuronas)

    def num_sinapsis(self):
        return len(self.aristas)

    def grado_promedio(self):
        return sum(len(n.vecinos) for n in self.neuronas.values()) / len(self.neuronas)

    def rango_longitudes(self):
        """Retorna (mínimo, promedio, máximo) de los largos de las sinapsis."""
        if not self.aristas:
            return 0.0, 0.0, 0.0
        longitudes = [self._distancia_entre(a, b) for a, b in self.aristas]
        return min(longitudes), sum(longitudes) / len(longitudes), max(longitudes)
