# -*- coding: utf-8 -*-
"""Representación gráfica de una red de neuronas mediante un grafo en 3D.

Los vértices representan las neuronas y las aristas sus conexiones. Este archivo
se encarga de la cámara, los controles y el dibujo; la propagación de los impulsos
y los algoritmos de grafos están en red_neuronal_core.py. La geometría se dibuja
con shaders y buffers de ModernGL; Pyglet maneja la ventana, los eventos y el
texto. La idea es visualizar estos mecanismos en un modelo simplificado.

Controles
---------
* Arrastrar con botón izquierdo: orbitar la cámara.
* Rueda del mouse: acercar o alejar.
* Click breve sobre una neurona: dispararla.
* ESPACIO: lanzar un impulso desde una neurona aleatoria.
* P: enviar un impulso entre dos nodos aleatorios por el camino más corto.
* M: mostrar u ocultar el árbol de expansión mínima.
* R: regenerar la red.
* C: restablecer la cámara.
* ESC: cerrar la simulación.

Ejecución
---------
    python -m pip install -r requirements.txt
    python simulacion_red_neuronal_3d.py
"""

import math
import random
import importlib.util
import sys
from pathlib import Path

import pyglet
import render_moderngl as shapes
from render_moderngl import Renderer2D
from pyglet.window import key, mouse

try:
    from red_neuronal_core import EstadoNeurona, RedNeuronal
except ModuleNotFoundError as error:
    # Los adjuntos descargados pueden conservar el sufijo "(1)". Se admite
    # ese nombre sin obligar al usuario a renombrar ambos archivos.
    if error.name != "red_neuronal_core":
        raise
    candidatos_core = sorted(Path(__file__).parent.glob("red_neuronal_core*.py"))
    if not candidatos_core:
        raise
    ruta_core = candidatos_core[0]
    spec_core = importlib.util.spec_from_file_location(
        "red_neuronal_core", ruta_core
    )
    modulo_core = importlib.util.module_from_spec(spec_core)
    sys.modules[spec_core.name] = modulo_core
    spec_core.loader.exec_module(modulo_core)
    EstadoNeurona = modulo_core.EstadoNeurona
    RedNeuronal = modulo_core.RedNeuronal


ANCHO_INICIAL = 1180
ALTO_INICIAL = 780
ALTO_PANEL = 166

COLOR_FONDO = (7, 9, 19)
COLOR_PANEL = (14, 17, 31)
COLOR_REJILLA = (30, 37, 61)
COLOR_SINAPSIS = (55, 70, 106)
COLOR_SINAPSIS_ACTIVA = (125, 225, 255)
COLOR_RUTA_MINIMA = (255, 203, 92)
COLOR_ARBOL_MINIMO = (173, 92, 255)
COLOR_REPOSO = (82, 105, 158)
COLOR_BORDE = (32, 42, 72)
COLOR_BRILLO = (150, 184, 225)
COLOR_DISPARO = (176, 250, 255)
COLOR_HALO = (255, 91, 211)
COLOR_REFRACTARIA = (105, 65, 125)
COLOR_SELECCION = (255, 221, 105)
COLOR_TEXTO = (210, 220, 240, 255)
COLOR_TEXTO_TENUE = (136, 151, 184, 255)
COLOR_BOTON = (39, 126, 151)
COLOR_BOTON_HOVER = (54, 165, 194)


def limitar(valor, minimo, maximo):
    return max(minimo, min(maximo, valor))


def mezclar_color(color, factor):
    """Atenúa un RGB sin cambiar su tono; factor debe estar entre 0 y 1."""
    factor = limitar(factor, 0.0, 1.0)
    return tuple(int(limitar(c * factor, 0, 255)) for c in color)


class CamaraOrbital:
    """Proyecta las posiciones 3D sobre la pantalla usando perspectiva.

    La posición de cada neurona se conserva en el grafo. Al orbitar solo cambia
    el punto de vista, sin mover las neuronas ni modificar sus conexiones.
    """

    def __init__(self):
        self.reiniciar()

    def reiniciar(self):
        self.yaw = math.radians(38.0)
        self.pitch = math.radians(-20.0)
        self.distancia = 17.5
        self.distancia_minima = 6.0
        self.distancia_maxima = 80.0
        self.objetivo = (0.0, 0.0, 0.0)
        self.fov = math.radians(52.0)

    def orbitar(self, dx, dy):
        self.yaw += dx * 0.008
        self.pitch = limitar(
            self.pitch + dy * 0.008,
            math.radians(-82),
            math.radians(82),
        )

    def zoom(self, pasos):
        self.distancia *= math.pow(0.9, pasos)
        self.distancia = limitar(
            self.distancia, self.distancia_minima, self.distancia_maxima
        )

    def encuadrar(self, puntos):
        """Centra la cámara y calcula una distancia apropiada para la nube."""
        xs, ys, zs = zip(*puntos)
        self.objetivo = (
            (min(xs) + max(xs)) / 2,
            (min(ys) + max(ys)) / 2,
            (min(zs) + max(zs)) / 2,
        )
        diagonal = math.sqrt(
            (max(xs) - min(xs)) ** 2
            + (max(ys) - min(ys)) ** 2
            + (max(zs) - min(zs)) ** 2
        )
        distancia_ajustada = max(12.0, diagonal * 1.18)
        self.distancia = distancia_ajustada
        self.distancia_minima = max(5.0, distancia_ajustada * 0.30)
        self.distancia_maxima = distancia_ajustada * 3.0

    def proyectar(self, punto, ancho, alto, alto_panel=0):
        """Retorna (x_pantalla, y_pantalla, profundidad, escala) o None."""
        x = punto[0] - self.objetivo[0]
        y = punto[1] - self.objetivo[1]
        z = punto[2] - self.objetivo[2]

        cy, sy = math.cos(self.yaw), math.sin(self.yaw)
        cp, sp = math.cos(self.pitch), math.sin(self.pitch)

        # Giro inverso del mundo: primero alrededor de Y y luego de X.
        x1 = cy * x - sy * z
        z1 = sy * x + cy * z
        y1 = cp * y - sp * z1
        z2 = sp * y + cp * z1

        profundidad = self.distancia - z2
        if profundidad <= 0.25:
            return None

        alto_escena = max(1, alto - alto_panel)
        focal = 0.5 * min(ancho, alto_escena) / math.tan(self.fov / 2)
        escala = focal / profundidad
        px = ancho * 0.5 + x1 * escala
        py = alto_escena * 0.5 + y1 * escala
        return px, py, profundidad, escala


class Boton:
    """Botón del panel superior con detección del cursor y texto propio."""

    def __init__(self, renderer, texto, x=28, ancho=220, alto=40):
        self.texto = texto
        self.x = x
        self.y = 0
        self.ancho = ancho
        self.alto = alto
        self.hover = False
        self.batch = renderer.batch()
        self.batch_texto = pyglet.graphics.Batch()
        self.fondo = shapes.RoundedRectangle(
            self.x, self.y, self.ancho, self.alto, radius=10,
            color=COLOR_BOTON, batch=self.batch
        )
        self.borde = shapes.RoundedRectangle(
            self.x + 2, self.y + 2, self.ancho - 4, self.alto - 4,
            radius=8, color=(112, 220, 238), batch=self.batch
        )
        self.label = pyglet.text.Label(
            self.texto,
            font_name="Segoe UI",
            font_size=13,
            weight="bold",
            anchor_x="center",
            anchor_y="center",
            color=(255, 255, 255, 255),
            batch=self.batch_texto,
        )

    def ubicar(self, alto_ventana):
        self.y = alto_ventana - 56
        self.fondo.position = (self.x, self.y)
        self.borde.position = (self.x + 2, self.y + 2)
        self.label.x = self.x + self.ancho / 2
        self.label.y = self.y + self.alto / 2

    def contiene(self, x, y):
        return (
            self.x <= x <= self.x + self.ancho
            and self.y <= y <= self.y + self.alto
        )

    def dibujar(self):
        color = COLOR_BOTON_HOVER if self.hover else COLOR_BOTON
        self.fondo.color = color
        self.borde.opacity = 80 if self.hover else 25
        self.batch.draw()
        self.batch_texto.draw()

    def cambiar_texto(self, texto):
        self.texto = texto
        self.label.text = texto


class VentanaSimulacion3D(pyglet.window.Window):
    """Conecta la simulación lógica con los controles y su representación 3D."""

    def __init__(self):
        super().__init__(
            ANCHO_INICIAL,
            ALTO_INICIAL,
            caption="Red neuronal 3D — propagación sináptica",
            resizable=True,
            config=pyglet.gl.Config(
                double_buffer=True, major_version=3, minor_version=3,
            ),
        )
        # El panel necesita espacio para sus tres botones, la información y la
        # ayuda. El texto se ajusta al ancho cuando cambia la ventana.
        self.set_minimum_size(1000, 540)
        self.renderer = Renderer2D(self)

        self.camara = CamaraOrbital()
        self.semilla = 7
        self.boton_onda = Boton(self.renderer, "Onda aleatoria", x=28, ancho=165)
        self.boton_ruta = Boton(self.renderer, "Ruta mínima aleatoria", x=205, ancho=220)
        self.boton_arbol = Boton(self.renderer, "Árbol mínimo: oculto", x=437, ancho=210)
        self.mostrar_arbol_minimo = False
        self.aristas_arbol_minimo = set()
        self.neurona_seleccionada = None
        self.proyecciones = {}
        self.arrastrando = False
        self.movimiento_arrastre = 0.0
        self._construir_red()

        self.label_info = pyglet.text.Label(
            "",
            font_name="Segoe UI",
            font_size=11,
            color=COLOR_TEXTO,
            width=self.width - 56,
            multiline=True,
            anchor_y="top",
        )
        self.label_ayuda = pyglet.text.Label(
            "Arrastrar = orbitar · Rueda = zoom · Click = disparar · "
            "ESPACIO = onda · P = ruta mínima · M = árbol mínimo · "
            "R = regenerar · C = centrar · ESC = salir",
            font_name="Segoe UI",
            font_size=10,
            color=COLOR_TEXTO_TENUE,
            width=self.width - 56,
            multiline=True,
            anchor_y="top",
        )
        self.batch_panel = self.renderer.batch()
        self.fondo_panel = shapes.Rectangle(
            0, self.height - ALTO_PANEL, self.width, ALTO_PANEL,
            color=COLOR_PANEL, batch=self.batch_panel
        )
        self.fondo_panel.opacity = 248
        self.separador_panel = shapes.Line(
            0, self.height - ALTO_PANEL, self.width, self.height - ALTO_PANEL,
            thickness=1.5, color=(47, 58, 91), batch=self.batch_panel
        )
        pyglet.clock.schedule_interval(self._actualizar, 1 / 60.0)

    def _construir_red(self):
        """Genera la red y calcula el árbol que se puede mostrar con M."""
        # Las dimensiones solo fijan la cantidad total y la extensión aproximada.
        # En topología espacial NO representan filas o capas visibles.
        columnas, filas, capas = 8, 5, 3
        esp_x, esp_y, esp_z = 2.0, 1.8, 2.2
        self.red = RedNeuronal(
            filas=filas,
            columnas=columnas,
            capas=capas,
            espaciado_x=esp_x,
            espaciado_y=esp_y,
            espaciado_z=esp_z,
            topologia="espacial",
            expansion_espacial=1.70,
            separacion_minima=0.50,
            vecinos_minimos=2,
            conexiones_extra_por_nodo=2,
            prob_conexion_larga=0.07,
            tiempo_segun_distancia=True,
            semilla=self.semilla,
        )
        self._encuadrar_camara()
        self.neurona_seleccionada = None
        self.proyecciones = {}
        self.aristas_arbol_minimo = self.red.arbol_expansion_minima()
        self._crear_graficos_mundo()

    def _encuadrar_camara(self):
        puntos = [
            (n.x, n.y, n.z) for n in self.red.neuronas.values()
        ]
        self.camara.encuadrar(puntos)

    def _punto_neurona(self, neurona):
        return neurona.x, neurona.y, neurona.z

    def _crear_graficos_mundo(self):
        """Crea las primitivas una vez; cada frame solo cambia sus atributos."""
        self._liberar_graficos_mundo()
        self.batch_rejilla = self.renderer.batch()
        self.batch_sinapsis = self.renderer.batch()
        self.batch_halos = self.renderer.batch()
        self.batch_bordes = self.renderer.batch()
        self.batch_somas = self.renderer.batch()
        self.batch_brillos = self.renderer.batch()
        self.batch_impulsos = self.renderer.batch()

        self.graficos_rejilla = []
        # Una red espacial se deja flotando, sin rejilla de fondo, para no
        # sugerir filas o capas que ya no existen en la topología.

        self.lineas_sinapsis = {
            arista: shapes.Line(
                0, 0, 0, 0, color=COLOR_SINAPSIS, batch=self.batch_sinapsis
            )
            for arista in self.red.aristas
        }

        self.graficos_neurona = {}
        for nid in self.red.neuronas:
            halo = shapes.Circle(0, 0, 1, color=COLOR_HALO, batch=self.batch_halos)
            seleccion = shapes.Circle(
                0, 0, 1, color=COLOR_SELECCION, batch=self.batch_halos
            )
            borde = shapes.Circle(0, 0, 1, color=COLOR_BORDE, batch=self.batch_bordes)
            soma = shapes.Circle(0, 0, 1, color=COLOR_REPOSO, batch=self.batch_somas)
            brillo = shapes.Circle(0, 0, 1, color=COLOR_BRILLO, batch=self.batch_brillos)
            for forma in (halo, seleccion, borde, soma, brillo):
                forma.visible = False
            self.graficos_neurona[nid] = (halo, seleccion, borde, soma, brillo)

        # Crece cuando sea necesario y luego se reutiliza.
        self.pool_impulsos = []

    def _liberar_graficos_mundo(self):
        """Libera las formas anteriores al regenerar, incluidas las del pool."""
        for linea, _, _ in getattr(self, "graficos_rejilla", []):
            linea.delete()
        for linea in getattr(self, "lineas_sinapsis", {}).values():
            linea.delete()
        for formas in getattr(self, "graficos_neurona", {}).values():
            for forma in formas:
                forma.delete()
        for formas in getattr(self, "pool_impulsos", []):
            for forma in formas:
                forma.delete()
        for nombre in (
            "batch_rejilla", "batch_sinapsis", "batch_halos", "batch_bordes",
            "batch_somas", "batch_brillos", "batch_impulsos",
        ):
            batch = getattr(self, nombre, None)
            if batch is not None:
                batch.release()

    def _actualizar(self, dt):
        # Evita saltos gigantes si la ventana fue pausada o arrastrada.
        self.red.actualizar(min(dt, 0.05))

    def _lanzar_impulso(self):
        self.neurona_seleccionada = self.red.lanzar_impulso_aleatorio()

    def _lanzar_ruta_minima(self):
        origen, _, _ = self.red.lanzar_impulso_por_ruta_minima()
        self.neurona_seleccionada = origen

    def _alternar_arbol_minimo(self):
        self.mostrar_arbol_minimo = not self.mostrar_arbol_minimo
        estado = "visible" if self.mostrar_arbol_minimo else "oculto"
        self.boton_arbol.cambiar_texto(f"Árbol mínimo: {estado}")

    def _seleccionar_neurona(self, x, y):
        candidatos = []
        for nid, (px, py, profundidad, radio) in self.proyecciones.items():
            distancia_2 = (px - x) ** 2 + (py - y) ** 2
            if distancia_2 <= (radio + 8) ** 2:
                candidatos.append((distancia_2, profundidad, nid))
        if candidatos:
            _, _, nid = min(candidatos)
            self.neurona_seleccionada = nid
            self.red.disparar_neurona(nid)

    # -- interacción ---------------------------------------------------------
    def on_mouse_press(self, x, y, button, modifiers):
        botones = (self.boton_onda, self.boton_ruta, self.boton_arbol)
        for boton in botones:
            boton.ubicar(self.height)
        if button == mouse.LEFT:
            if self.boton_onda.contiene(x, y):
                self._lanzar_impulso()
                return
            if self.boton_ruta.contiene(x, y):
                self._lanzar_ruta_minima()
                return
            if self.boton_arbol.contiene(x, y):
                self._alternar_arbol_minimo()
                return
            if y < self.height - ALTO_PANEL:
                self.arrastrando = True
                self.movimiento_arrastre = 0.0

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        if self.arrastrando and buttons & mouse.LEFT:
            self.camara.orbitar(dx, dy)
            self.movimiento_arrastre += abs(dx) + abs(dy)

    def on_mouse_release(self, x, y, button, modifiers):
        if button == mouse.LEFT and self.arrastrando:
            if self.movimiento_arrastre < 5.0:
                self._seleccionar_neurona(x, y)
            self.arrastrando = False

    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        if y < self.height - ALTO_PANEL:
            self.camara.zoom(scroll_y)

    def on_mouse_motion(self, x, y, dx, dy):
        for boton in (self.boton_onda, self.boton_ruta, self.boton_arbol):
            boton.ubicar(self.height)
            boton.hover = boton.contiene(x, y)

    def on_key_press(self, symbol, modifiers):
        if symbol == key.SPACE:
            self._lanzar_impulso()
        elif symbol == key.P:
            self._lanzar_ruta_minima()
        elif symbol == key.M:
            self._alternar_arbol_minimo()
        elif symbol == key.R:
            self.semilla = random.randint(0, 1_000_000)
            self._construir_red()
        elif symbol == key.C:
            self.camara.reiniciar()
            self._encuadrar_camara()
        elif symbol == key.ESCAPE:
            self.close()

    def close(self):
        # La actualización queda registrada en el reloj de pyglet. Se retira al
        # cerrar para que no siga ejecutándose si se abre otra ventana.
        pyglet.clock.unschedule(self._actualizar)
        renderer = getattr(self, "renderer", None)
        if renderer is not None and self.context is not None:
            self.switch_to()
            renderer.release()
        super().close()

    # -- dibujo 3D proyectado -----------------------------------------------
    def _proyectar(self, punto):
        return self.camara.proyectar(
            punto, self.width, self.height, alto_panel=ALTO_PANEL
        )

    def _dibujar_rejilla(self):
        for linea, a, b in self.graficos_rejilla:
            pa, pb = self._proyectar(a), self._proyectar(b)
            linea.visible = pa is not None and pb is not None
            if linea.visible:
                linea.position = (pa[0], pa[1])
                linea.x2, linea.y2 = pb[0], pb[1]
                linea.thickness = 1.0
                linea.opacity = 80
        self.batch_rejilla.draw()

    def _dibujar_sinapsis(self):
        activas = {
            (min(i.origen, i.destino), max(i.origen, i.destino))
            for i in self.red.impulsos
        }
        ruta_minima = {
            (min(a, b), max(a, b))
            for a, b in zip(
                self.red.ultima_ruta_minima,
                self.red.ultima_ruta_minima[1:],
            )
        }
        for a, b in self.red.aristas:
            na, nb = self.red.neuronas[a], self.red.neuronas[b]
            pa = self._proyectar(self._punto_neurona(na))
            pb = self._proyectar(self._punto_neurona(nb))
            linea = self.lineas_sinapsis[(a, b)]
            linea.visible = pa is not None and pb is not None
            if not linea.visible:
                continue
            profundidad = (pa[2] + pb[2]) / 2
            factor = limitar(1.35 - profundidad / 28.0, 0.42, 1.0)
            largo_relativo = max(
                self.red._distancia_entre(a, b) / max(
                    self.red.longitud_sinapsis_referencia, 1e-9
                ),
                1e-9,
            )
            activa = (min(a, b), max(a, b)) in activas
            en_ruta = (min(a, b), max(a, b)) in ruta_minima
            en_arbol = (
                self.mostrar_arbol_minimo
                and (min(a, b), max(a, b)) in self.aristas_arbol_minimo
            )
            atenuacion_largo = limitar(1.10 / math.sqrt(largo_relativo), 0.52, 1.0)
            if activa:
                color = COLOR_SINAPSIS_ACTIVA
                grosor = 3.2
            elif en_arbol:
                color = COLOR_ARBOL_MINIMO
                grosor = 2.8
            elif en_ruta:
                color = COLOR_RUTA_MINIMA
                grosor = 2.4
            else:
                color = mezclar_color(
                    COLOR_SINAPSIS, factor * atenuacion_largo
                )
                grosor = limitar(
                    (pa[3] + pb[3]) * 0.012 / math.sqrt(largo_relativo),
                    0.65,
                    1.7,
                )
            linea.position = (pa[0], pa[1])
            linea.x2, linea.y2 = pb[0], pb[1]
            linea.thickness = grosor
            linea.color = color
            linea.opacity = (
                250 if activa or en_arbol or en_ruta
                else int(95 + 100 * factor)
            )
        self.batch_sinapsis.draw()

    def _dibujar_impulsos(self):
        while len(self.pool_impulsos) < len(self.red.impulsos):
            halo = shapes.Circle(0, 0, 1, color=COLOR_HALO, batch=self.batch_impulsos)
            nucleo = shapes.Circle(
                0, 0, 1, color=COLOR_DISPARO, batch=self.batch_impulsos
            )
            self.pool_impulsos.append((halo, nucleo))

        for indice, impulso in enumerate(self.red.impulsos):
            a = self.red.neuronas[impulso.origen]
            b = self.red.neuronas[impulso.destino]
            t = limitar(impulso.progreso, 0.0, 1.0)
            punto = (
                a.x + (b.x - a.x) * t,
                a.y + (b.y - a.y) * t,
                a.z + (b.z - a.z) * t,
            )
            p = self._proyectar(punto)
            halo, nucleo = self.pool_impulsos[indice]
            halo.visible = nucleo.visible = p is not None
            if p is None:
                continue
            x, y, _, escala = p
            radio = limitar(0.15 * escala, 3.2, 8.5)
            halo.position = nucleo.position = (x, y)
            halo.radius = radio * 2.2
            halo.opacity = 72
            nucleo.radius = radio
            nucleo.opacity = 255

        for indice in range(len(self.red.impulsos), len(self.pool_impulsos)):
            halo, nucleo = self.pool_impulsos[indice]
            halo.visible = nucleo.visible = False
        self.batch_impulsos.draw()

    def _dibujar_neuronas(self):
        self.proyecciones = {}
        for nid, neurona in self.red.neuronas.items():
            p = self._proyectar(self._punto_neurona(neurona))
            halo, seleccion, borde, soma, brillo = self.graficos_neurona[nid]
            if p is None:
                for forma in (halo, seleccion, borde, soma, brillo):
                    forma.visible = False
                continue
            x, y, profundidad, escala = p
            radio = limitar(0.22 * escala, 3.8, 13.5)
            halo.visible = False
            if neurona.estado == EstadoNeurona.DISPARANDO:
                fase = limitar(
                    neurona.reloj_estado / neurona.tiempo_disparo, 0.0, 1.0
                )
                radio *= 1.0 + 0.30 * math.sin(fase * math.pi)
                color = COLOR_DISPARO
                halo.position = (x, y)
                halo.radius = radio * (2.0 + fase)
                halo.opacity = int(115 * (1.0 - fase))
                halo.visible = True
            elif neurona.estado == EstadoNeurona.REFRACTARIA:
                color = COLOR_REFRACTARIA
            else:
                factor = limitar(1.40 - profundidad / 28.0, 0.55, 1.0)
                color = mezclar_color(COLOR_REPOSO, factor)

            seleccion.position = (x, y)
            seleccion.radius = radio + 4
            seleccion.opacity = 205
            seleccion.visible = nid == self.neurona_seleccionada

            borde.position = soma.position = (x, y)
            borde.radius = radio + 1.8
            borde.visible = True
            soma.radius = radio
            soma.color = color
            soma.visible = True

            # Brillo desplazado: da volumen aparente al soma sin requerir mallas.
            brillo.position = (x - radio * 0.28, y + radio * 0.30)
            brillo.radius = max(1.2, radio * 0.30)
            brillo.color = (
                COLOR_BRILLO
                if neurona.estado == EstadoNeurona.REPOSO
                else (255, 255, 255)
            )
            brillo.opacity = 125
            brillo.visible = True
            self.proyecciones[nid] = (x, y, profundidad, radio)

        self.batch_halos.draw()
        self.batch_bordes.draw()
        self.batch_somas.draw()
        self.batch_brillos.draw()

    def _dibujar_panel(self):
        y_panel = self.height - ALTO_PANEL
        self.fondo_panel.position = (0, y_panel)
        self.fondo_panel.width = self.width
        self.separador_panel.position = (0, y_panel)
        self.separador_panel.x2 = self.width
        self.separador_panel.y2 = y_panel
        self.batch_panel.draw()

        for boton in (self.boton_onda, self.boton_ruta, self.boton_arbol):
            boton.ubicar(self.height)
            boton.dibujar()
        largo_min, largo_medio, largo_max = self.red.rango_longitudes()
        self.label_info.text = (
            f"{self.red.num_neuronas()} neuronas · "
            f"{self.red.num_sinapsis()} sinapsis · "
            f"largos {largo_min:.1f}/{largo_medio:.1f}/{largo_max:.1f} · "
            f"{len(self.red.impulsos)} en viaje · "
            f"{len(self.red.eventos_disparo)} pendientes · "
            f"refracción {self.red.tiempo_refractario:.2f} s · "
            f"{self.red.impulsos_bloqueados} bloqueados"
        )
        if self.red.ultima_ruta_minima:
            origen = self.red.ultimo_origen_ruta
            destino = self.red.ultimo_destino_ruta
            costo = sum(
                self.red._distancia_entre(a, b)
                for a, b in zip(
                    self.red.ultima_ruta_minima,
                    self.red.ultima_ruta_minima[1:],
                )
            )
            detalle_ruta = (
                f" · ruta {origen}→{destino}: "
                f"{len(self.red.ultima_ruta_minima) - 1} saltos, costo {costo:.1f}"
            )
        else:
            detalle_ruta = ""
        self.label_info.text += detalle_ruta
        self.label_info.x = 28
        self.label_info.y = self.height - 73
        self.label_info.width = max(1, self.width - 56)
        self.label_ayuda.x = 28
        self.label_ayuda.y = self.height - 123
        self.label_ayuda.width = max(1, self.width - 56)
        self.label_info.draw()
        self.label_ayuda.draw()

    def on_draw(self):
        self.renderer.clear(tuple(c / 255 for c in COLOR_FONDO) + (1.0,))
        self._dibujar_rejilla()
        self._dibujar_sinapsis()
        self._dibujar_impulsos()
        self._dibujar_neuronas()
        self._dibujar_panel()


def main():
    VentanaSimulacion3D()
    pyglet.app.run()


if __name__ == "__main__":
    main()
