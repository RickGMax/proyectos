# Redes complejas: impulsos nerviosos en 3D

La idea de este proyecto es utilizar propiedades de grafos para representar una red de neuronas y observar cómo se propaga un impulso entre ellas. Los vértices representan las neuronas y las aristas vendrían siendo sus conexiones. La parte gráfica permite recorrer la red, activar una neurona y comparar la propagación con una ruta mínima o un árbol de costo mínimo.

Es una representación simplificada para explorar grafos y computación gráfica con una temática biológica. Los tiempos y las conexiones son parámetros del modelo.

## Cómo ejecutarlo

Descomprime el archivo y abre una terminal dentro de `3D_neuronas`. Mantén los dos archivos de Python en esa misma carpeta.

```powershell
python -m pip install -r requirements.txt
python simulacion_red_neuronal_3d.py
```

Probado con Python 3.11.4 y Pyglet 2.1.19 en Windows. Pyglet es la única dependencia externa de esta versión. Para abrir la ventana se necesita soporte para OpenGL 3.3 o superior, como indica la [documentación de Pyglet](https://github.com/pyglet/pyglet#requirements).

## Controles

| Control | Acción |
| --- | --- |
| Clic izquierdo sobre una neurona | Inicia un pulso si la neurona está en reposo. |
| Arrastrar con el botón izquierdo | Gira la cámara alrededor de la red. |
| Rueda del mouse | Acerca o aleja la cámara. |
| `Espacio` | Intenta iniciar una onda desde una neurona aleatoria. |
| `P` | Elige dos neuronas y calcula una ruta mínima con Dijkstra. |
| `M` | Muestra u oculta el árbol de costo mínimo calculado con Prim. |
| `R` | Genera otra red y borra la actividad anterior. |
| `C` | Restablece la orientación y centra la cámara. |
| `Esc` | Cierra la simulación. |

Los tres botones del panel hacen lo mismo que `Espacio`, `P` y `M`.

## Qué representa la red

La simulación parte con **120 neuronas** distribuidas en el espacio. Para construir esta distribución se genera primero un árbol de costo mínimo que conecta los vértices. Luego se agregan conexiones cercanas y algunos enlaces largos, lo que permite tener ciclos y caminos alternativos.

En esta configuración, filas, columnas y capas fijan la cantidad de neuronas y la extensión aproximada de la nube. No representan filas visibles. El núcleo también permite usar `topologia="grilla"` para comparar con una distribución más regular; en esa topología las capas pueden quedar desconectadas según sus probabilidades de conexión.

Cada neurona pasa por tres estados:

1. **Reposo:** puede recibir un impulso.
2. **Disparando:** se ilumina y envía el pulso a sus conexiones disponibles.
3. **Refractaria:** queda bloqueada durante un intervalo antes de volver al reposo.

Para evitar loops de propagación, cada onda tiene un identificador. Una misma onda puede activar una sola vez a cada neurona, aunque encuentre otro camino para volver a ella. El período refractario también limita la llegada de ondas distintas muy seguidas. Cuando ya no quedan impulsos ni eventos de esa onda, se libera su historial.

Un impulso puede quedar bloqueado si la neurona de destino está activa, refractaria o ya procesó esa onda. Por eso, lanzar varios pulsos seguidos puede producir recorridos distintos de los que se ven con la red en reposo.

## Dijkstra y Prim

**Dijkstra** busca el camino con menor suma de distancias entre dos neuronas. Con `P` se destaca ese camino y se intenta enviar un impulso solo por sus aristas, sin que se bifurque. La ruta queda marcada aunque el impulso encuentre una neurona bloqueada. El costo corresponde al largo geométrico, no necesariamente al menor tiempo de viaje.

**Prim** encuentra las conexiones que unen toda la red con el menor largo total, sin formar ciclos. La idea es partir de una neurona e ir agregando la conexión más corta que alcance una neurona fuera del árbol. Con `M` se destacan esas aristas, pero las demás conexiones siguen existiendo y transmitiendo pulsos. Si se usa una grilla desconectada, el resultado es un bosque: un árbol por componente.

Uso Prim en dos partes. Al generar la nube, cualquier par de posiciones puede conectarse, así que se calcula el árbol con una variante de `O(V²)`, sin ordenar todas las aristas para ese paso. Para mostrar el árbol de la red ya construida, se recorren las listas de vecinos y se eligen las conexiones con una cola de prioridad.

Tener más aristas que nodos no alcanza para considerar denso un grafo. También importa cuántas conexiones hay respecto de las posibles y cómo están guardadas. En esta simulación se consideran todos los pares al construir la nube, mientras que la red final conserva solo parte de esas conexiones. El generador todavía ordena distancias para elegir vecinos y enlaces largos, por lo que el cambio a Prim no elimina ese costo del proceso completo. La [explicación de Princeton](https://algs4.cs.princeton.edu/43mst/index.php) desarrolla las variantes de Prim y su relación con la representación del grafo.

En el dibujo, la ruta mínima se marca en amarillo y el árbol en violeta. Si ambos comparten una arista, se muestra violeta. Los impulsos activos se destacan en celeste; ese color tiene prioridad sobre las otras marcas. La neurona seleccionada tiene un borde amarillo.

## Parámetros para experimentar

La configuración inicial está en `_construir_red()`, dentro de `simulacion_red_neuronal_3d.py`.

| Parámetro | Valor inicial | Qué cambia |
| --- | --- | --- |
| `columnas`, `filas`, `capas` | `8`, `5`, `3` | Su producto fija la cantidad de neuronas. |
| `semilla` | `7` | Permite repetir la distribución inicial; `R` elige otra semilla. |
| `expansion_espacial` | `1.70` | Extensión de la nube de neuronas. |
| `separacion_minima` | `0.50` | Separación buscada, como fracción del menor espaciado. |
| `vecinos_minimos` | `2` | Cantidad mínima de vecinos buscada, limitada por los vértices disponibles. |
| `conexiones_extra_por_nodo` | `2` | Cantidad de conexiones locales adicionales que se intentan agregar por nodo. |
| `prob_conexion_larga` | `0.07` | Fija un objetivo de enlaces largos de aproximadamente el 7 % de la cantidad de neuronas. |
| `tiempo_segun_distancia` | `True` | Ajusta el tiempo de viaje según el largo de cada arista. |

La separación mínima se intenta respetar al generar posiciones. Si se agotan los intentos, se completa la nube aunque algunas neuronas queden más cerca. La generación compara pares de neuronas, por lo que aumentar mucho su cantidad incrementa el tiempo y la memoria necesarios.

Los tiempos base se definen en `red_neuronal_core.py` y también se pueden pasar al constructor `RedNeuronal`:

| Parámetro | Segundos | Qué representa |
| --- | --- | --- |
| `tiempo_viaje_sinapsis` | `0.45` | Tiempo de referencia para recorrer una arista. |
| `tiempo_disparo` | `0.18` | Duración del estado de disparo. |
| `tiempo_refractario` | `0.90` | Tiempo de bloqueo después del disparo. |
| `retardo_sinaptico` | `0.05` | Espera entre recibir un impulso y activar la neurona. |

Cuando el tiempo depende de la distancia, se compara cada arista con la longitud mediana de las conexiones. El factor queda entre `0.45` y `3.2` veces el tiempo base para mantener la propagación visible. La simulación avanza por pasos: la transmisión se resuelve en las actualizaciones y no como una solución continua de la actividad neuronal.

## Organización del código

```text
3D_neuronas/
├── red_neuronal_core.py
├── simulacion_red_neuronal_3d.py
├── requirements.txt
├── README.md
└── tests/
    └── test_red_neuronal_core.py
```

- `red_neuronal_core.py` construye el grafo, maneja los estados y la propagación, y calcula los caminos y el árbol mínimo. Usa la biblioteca estándar de Python y se puede ejecutar sin abrir una ventana.
- `simulacion_red_neuronal_3d.py` proyecta las posiciones 3D en pantalla y maneja la cámara, los controles y el panel. Reutiliza las formas gráficas durante el dibujo.
- `tests/` comprueba los tiempos, los ciclos de propagación, la ruta mínima, Prim y los parámetros de entrada.

Para ejecutar las pruebas del núcleo desde esta carpeta:

```powershell
python -m unittest discover -s tests -v
```

## Si no abre

- Si aparece `No module named 'pyglet'`, instala los requisitos usando el mismo intérprete con el que ejecutas la simulación.
- Si aparece `No module named 'red_neuronal_core'`, comprueba que descomprimiste ambos archivos y que están en la misma carpeta.
- Si falla la creación del contexto OpenGL, revisa el soporte gráfico y los controladores del equipo. Las pruebas del núcleo se pueden ejecutar sin soporte gráfico.
