"""Pruebas del modelo sin abrir la ventana de la simulación."""

import math
import unittest

from red_neuronal_core import EstadoNeurona, ImpulsoEnViaje, Neurona, RedNeuronal


class PruebasDeTiempo(unittest.TestCase):
    def test_el_tiempo_sobrante_pasa_a_la_refraccion(self):
        neurona = Neurona(0, 0, 0, tiempo_disparo=0.2, tiempo_refractario=0.5)
        neurona.disparar()
        neurona.actualizar(0.4)
        self.assertEqual(neurona.estado, EstadoNeurona.REFRACTARIA)
        self.assertAlmostEqual(neurona.reloj_estado, 0.2)
        neurona.actualizar(0.31)
        self.assertEqual(neurona.estado, EstadoNeurona.REPOSO)

    def test_un_paso_puede_completar_ambos_estados(self):
        neurona = Neurona(0, 0, 0, tiempo_disparo=0.2, tiempo_refractario=0.5)
        neurona.disparar()
        neurona.actualizar(1.0)
        self.assertEqual(neurona.estado, EstadoNeurona.REPOSO)
        self.assertTrue(neurona.disparar())

    def test_refraccion_cero_no_agrega_un_paso_de_espera(self):
        neurona = Neurona(0, 0, 0, tiempo_disparo=0.2, tiempo_refractario=0)
        neurona.disparar()
        neurona.actualizar(0.2)
        self.assertEqual(neurona.estado, EstadoNeurona.REPOSO)

    def test_dt_invalido_no_modifica_la_red(self):
        red = RedNeuronal(1, 2, 1, 1)
        red.disparar_neurona(0)
        for dt in (-0.1, math.nan, math.inf, -math.inf):
            with self.subTest(dt=dt), self.assertRaises(ValueError):
                red.actualizar(dt)
        self.assertEqual(red.neuronas[0].reloj_estado, 0)
        self.assertEqual(red.impulsos[0].progreso, 0)

    def test_dt_cero_no_consume_un_evento(self):
        red = RedNeuronal(1, 2, 1, 1, retardo_sinaptico=0)
        red.disparar_neurona(0)
        red.actualizar(0.45)
        self.assertEqual(len(red.eventos_disparo), 1)
        red.actualizar(0)
        self.assertEqual(len(red.eventos_disparo), 1)
        self.assertEqual(red.neuronas[1].estado, EstadoNeurona.REPOSO)

    def test_impulso_rechaza_duracion_invalida(self):
        for duracion in (0, -1, math.inf, math.nan):
            with self.subTest(duracion=duracion), self.assertRaises(ValueError):
                ImpulsoEnViaje(0, 1, 0, duracion=duracion)


class PruebasDeGrafo(unittest.TestCase):
    def test_dijkstra_usa_longitud_y_no_cantidad_de_saltos(self):
        red = RedNeuronal(2, 2, 1, 1, prob_conexion_diagonal=0)
        red.neuronas[1].x = 10
        self.assertEqual(red.camino_mas_corto(0, 3), [0, 2, 3])
        self.assertEqual(red.camino_mas_corto(2, 2), [2])

    def test_red_desconectada_retorna_camino_vacio_y_bosque(self):
        red = RedNeuronal(1, 2, 1, 1, capas=2, prob_conexion_entre_capas=0)
        self.assertEqual(red.camino_mas_corto(0, 3), [])
        self.assertEqual(red.arbol_expansion_minima(), {(0, 1), (2, 3)})

    def test_kruskal_conecta_todos_con_costo_minimo_conocido(self):
        red = RedNeuronal(2, 2, 1, 1, prob_conexion_diagonal=1)
        arbol = red.arbol_expansion_minima()
        self.assertEqual(len(arbol), 3)
        self.assertTrue(arbol <= red.aristas)
        self.assertEqual({n for arista in arbol for n in arista}, set(red.neuronas))
        self.assertAlmostEqual(sum(red._distancia_entre(a, b) for a, b in arbol), 3)

    def test_red_espacial_es_reproducible_y_conectada(self):
        opciones = dict(filas=2, columnas=3, capas=2, espaciado_x=1,
                        espaciado_y=1, topologia="espacial", semilla=41)
        red = RedNeuronal(**opciones)
        repetida = RedNeuronal(**opciones)
        self.assertEqual(red.aristas, repetida.aristas)
        self.assertEqual([(n.x, n.y, n.z) for n in red.neuronas.values()],
                         [(n.x, n.y, n.z) for n in repetida.neuronas.values()])
        for destino in red.neuronas:
            self.assertTrue(red.camino_mas_corto(0, destino))
        self.assertEqual(len(red.arbol_expansion_minima()), red.num_neuronas() - 1)

    def test_validacion_de_configuracion(self):
        casos = (
            {"filas": 1.5}, {"columnas": True}, {"capas": 0},
            {"espaciado_x": 0}, {"espaciado_y": -1}, {"espaciado_z": math.nan},
            {"jitter": -1}, {"jitter_z": math.inf},
            {"prob_conexion_diagonal": 1.1}, {"prob_conexion_entre_capas": -0.1},
            {"prob_conexion_larga": math.nan}, {"vecinos_minimos": 1.2},
            {"conexiones_extra_por_nodo": 0.5}, {"expansion_espacial": math.inf},
            {"tiempo_viaje_sinapsis": math.nan}, {"tiempo_disparo": math.inf},
            {"tiempo_refractario": math.nan}, {"retardo_sinaptico": -1},
        )
        for cambio in casos:
            opciones = dict(filas=2, columnas=2, espaciado_x=1, espaciado_y=1)
            opciones.update(cambio)
            with self.subTest(cambio=cambio), self.assertRaises(ValueError):
                RedNeuronal(**opciones)


class PruebasDePropagacion(unittest.TestCase):
    def contar_disparos(self, red):
        conteo = {nid: 0 for nid in red.neuronas}
        for nid, neurona in red.neuronas.items():
            original = neurona.disparar

            def registrar(nid=nid, original=original):
                resultado = original()
                if resultado:
                    conteo[nid] += 1
                return resultado

            neurona.disparar = registrar
        return conteo

    def completar_onda(self, red):
        for _ in range(1000):
            red.actualizar(0.01)
            if not red.impulsos and not red.eventos_disparo:
                return
        self.fail("la onda no terminó de propagarse")

    def test_ciclo_no_repite_disparos_y_libera_historial(self):
        red = RedNeuronal(2, 2, 1, 1, prob_conexion_diagonal=1,
                          tiempo_viaje_sinapsis=0.1, tiempo_disparo=0.02,
                          tiempo_refractario=0.01)
        conteo = self.contar_disparos(red)
        red.disparar_neurona(0)
        self.completar_onda(red)
        self.assertEqual(conteo, {0: 1, 1: 1, 2: 1, 3: 1})
        self.assertTrue(all(not n.ondas_procesadas for n in red.neuronas.values()))

    def test_ruta_minima_no_se_bifurca(self):
        red = RedNeuronal(2, 3, 1, 1, prob_conexion_diagonal=0, semilla=44)
        conteo = self.contar_disparos(red)
        origen, destino, camino = red.lanzar_impulso_por_ruta_minima()
        self.completar_onda(red)
        self.assertEqual(camino[0], origen)
        self.assertEqual(camino[-1], destino)
        self.assertEqual({nid for nid, veces in conteo.items() if veces}, set(camino))
        self.assertTrue(all(veces <= 1 for veces in conteo.values()))


if __name__ == "__main__":
    unittest.main()
